﻿namespace mychat
{
    partial class mainWin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_askid = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.lv_fri = new System.Windows.Forms.ListView();
            this.col_id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_ip = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_state = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_startchat = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lb_id = new System.Windows.Forms.Label();
            this.btn_groupchat = new System.Windows.Forms.Button();
            this.btn_ref = new System.Windows.Forms.Button();
            this.btn_dele = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("宋体", 11F);
            this.button1.Location = new System.Drawing.Point(138, 569);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 28);
            this.button1.TabIndex = 0;
            this.button1.Text = "退出";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 12F);
            this.label1.Location = new System.Drawing.Point(77, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "查询好友";
            // 
            // txt_askid
            // 
            this.txt_askid.Location = new System.Drawing.Point(172, 64);
            this.txt_askid.Name = "txt_askid";
            this.txt_askid.Size = new System.Drawing.Size(133, 25);
            this.txt_askid.TabIndex = 2;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("宋体", 11F);
            this.button2.Location = new System.Drawing.Point(362, 64);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 28);
            this.button2.TabIndex = 3;
            this.button2.Text = "查询";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lv_fri
            // 
            this.lv_fri.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col_id,
            this.col_ip,
            this.col_state});
            this.lv_fri.Font = new System.Drawing.Font("宋体", 11F);
            this.lv_fri.GridLines = true;
            this.lv_fri.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lv_fri.HideSelection = false;
            this.lv_fri.LabelWrap = false;
            this.lv_fri.Location = new System.Drawing.Point(45, 115);
            this.lv_fri.Name = "lv_fri";
            this.lv_fri.RightToLeftLayout = true;
            this.lv_fri.Size = new System.Drawing.Size(427, 372);
            this.lv_fri.TabIndex = 4;
            this.lv_fri.UseCompatibleStateImageBehavior = false;
            this.lv_fri.SelectedIndexChanged += new System.EventHandler(this.lv_fri_SelectedIndexChanged);
            // 
            // col_id
            // 
            this.col_id.Text = "好友学号";
            this.col_id.Width = 100;
            // 
            // col_ip
            // 
            this.col_ip.Text = "IP地址";
            this.col_ip.Width = 140;
            // 
            // col_state
            // 
            this.col_state.Text = "状态";
            // 
            // btn_startchat
            // 
            this.btn_startchat.Font = new System.Drawing.Font("宋体", 11F);
            this.btn_startchat.Location = new System.Drawing.Point(104, 516);
            this.btn_startchat.Name = "btn_startchat";
            this.btn_startchat.Size = new System.Drawing.Size(77, 28);
            this.btn_startchat.TabIndex = 5;
            this.btn_startchat.Text = "聊天";
            this.btn_startchat.UseVisualStyleBackColor = true;
            this.btn_startchat.Click += new System.EventHandler(this.btn_startchat_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 10F);
            this.label2.Location = new System.Drawing.Point(122, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "你好！";
            // 
            // lb_id
            // 
            this.lb_id.AutoSize = true;
            this.lb_id.Font = new System.Drawing.Font("宋体", 10F);
            this.lb_id.Location = new System.Drawing.Point(21, 9);
            this.lb_id.Name = "lb_id";
            this.lb_id.Size = new System.Drawing.Size(0, 17);
            this.lb_id.TabIndex = 7;
            // 
            // btn_groupchat
            // 
            this.btn_groupchat.Font = new System.Drawing.Font("宋体", 11F);
            this.btn_groupchat.Location = new System.Drawing.Point(224, 516);
            this.btn_groupchat.Name = "btn_groupchat";
            this.btn_groupchat.Size = new System.Drawing.Size(77, 28);
            this.btn_groupchat.TabIndex = 9;
            this.btn_groupchat.Text = "群聊";
            this.btn_groupchat.UseVisualStyleBackColor = true;
            this.btn_groupchat.Click += new System.EventHandler(this.btn_groupchat_Click);
            // 
            // btn_ref
            // 
            this.btn_ref.Font = new System.Drawing.Font("宋体", 11F);
            this.btn_ref.Location = new System.Drawing.Point(339, 516);
            this.btn_ref.Name = "btn_ref";
            this.btn_ref.Size = new System.Drawing.Size(77, 28);
            this.btn_ref.TabIndex = 10;
            this.btn_ref.Text = "刷新";
            this.btn_ref.UseVisualStyleBackColor = true;
            this.btn_ref.Click += new System.EventHandler(this.btn_ref_Click);
            // 
            // btn_dele
            // 
            this.btn_dele.Font = new System.Drawing.Font("宋体", 11F);
            this.btn_dele.Location = new System.Drawing.Point(282, 569);
            this.btn_dele.Name = "btn_dele";
            this.btn_dele.Size = new System.Drawing.Size(104, 28);
            this.btn_dele.TabIndex = 11;
            this.btn_dele.Text = "删除好友";
            this.btn_dele.UseVisualStyleBackColor = true;
            this.btn_dele.Click += new System.EventHandler(this.btn_dele_Click);
            // 
            // mainWin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(516, 624);
            this.Controls.Add(this.btn_dele);
            this.Controls.Add(this.btn_ref);
            this.Controls.Add(this.btn_groupchat);
            this.Controls.Add(this.lb_id);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_startchat);
            this.Controls.Add(this.lv_fri);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.txt_askid);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "mainWin";
            this.Text = "mainWin";
            this.Load += new System.EventHandler(this.mainWin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_askid;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListView lv_fri;
        private System.Windows.Forms.ColumnHeader col_id;
        private System.Windows.Forms.ColumnHeader col_ip;
        private System.Windows.Forms.Button btn_startchat;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lb_id;
        private System.Windows.Forms.ColumnHeader col_state;
        private System.Windows.Forms.Button btn_groupchat;
        private System.Windows.Forms.Button btn_ref;
        private System.Windows.Forms.Button btn_dele;
    }
}