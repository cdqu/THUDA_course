﻿namespace mychat
{
    partial class groupchat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtb_mess = new System.Windows.Forms.RichTextBox();
            this.rtb_fris = new System.Windows.Forms.RichTextBox();
            this.txt_gc = new System.Windows.Forms.TextBox();
            this.btn_gsend = new System.Windows.Forms.Button();
            this.btn_file = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtb_mess
            // 
            this.rtb_mess.Location = new System.Drawing.Point(32, 12);
            this.rtb_mess.Name = "rtb_mess";
            this.rtb_mess.ReadOnly = true;
            this.rtb_mess.Size = new System.Drawing.Size(432, 387);
            this.rtb_mess.TabIndex = 0;
            this.rtb_mess.Text = "";
            // 
            // rtb_fris
            // 
            this.rtb_fris.Location = new System.Drawing.Point(485, 12);
            this.rtb_fris.Name = "rtb_fris";
            this.rtb_fris.ReadOnly = true;
            this.rtb_fris.Size = new System.Drawing.Size(154, 387);
            this.rtb_fris.TabIndex = 1;
            this.rtb_fris.Text = "";
            // 
            // txt_gc
            // 
            this.txt_gc.Location = new System.Drawing.Point(32, 477);
            this.txt_gc.Name = "txt_gc";
            this.txt_gc.Size = new System.Drawing.Size(432, 25);
            this.txt_gc.TabIndex = 2;
            // 
            // btn_gsend
            // 
            this.btn_gsend.Font = new System.Drawing.Font("宋体", 10F);
            this.btn_gsend.Location = new System.Drawing.Point(485, 472);
            this.btn_gsend.Name = "btn_gsend";
            this.btn_gsend.Size = new System.Drawing.Size(78, 33);
            this.btn_gsend.TabIndex = 3;
            this.btn_gsend.Text = "发送";
            this.btn_gsend.UseVisualStyleBackColor = true;
            this.btn_gsend.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_file
            // 
            this.btn_file.Font = new System.Drawing.Font("宋体", 10F);
            this.btn_file.Location = new System.Drawing.Point(32, 422);
            this.btn_file.Name = "btn_file";
            this.btn_file.Size = new System.Drawing.Size(99, 33);
            this.btn_file.TabIndex = 4;
            this.btn_file.Text = "选择文件";
            this.btn_file.UseVisualStyleBackColor = true;
            this.btn_file.Click += new System.EventHandler(this.btn_file_Click);
            // 
            // groupchat
            // 
            this.AcceptButton = this.btn_gsend;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(658, 527);
            this.Controls.Add(this.btn_file);
            this.Controls.Add(this.btn_gsend);
            this.Controls.Add(this.txt_gc);
            this.Controls.Add(this.rtb_fris);
            this.Controls.Add(this.rtb_mess);
            this.Name = "groupchat";
            this.Text = "groupchat";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.groupchat_FormClosing);
            this.Load += new System.EventHandler(this.groupchat_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtb_mess;
        private System.Windows.Forms.RichTextBox rtb_fris;
        private System.Windows.Forms.TextBox txt_gc;
        private System.Windows.Forms.Button btn_gsend;
        private System.Windows.Forms.Button btn_file;
    }
}