﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace mychat
{
    public class Global  //多个窗体之间公用字段
    {
        public static string myid;  //我的学号
        public static Socket main_serv_sck;  //与中央服务器连接的套接字
        public static string friip;  //查询获得的好友IP
        public static List<string> IPpool = new List<string>();
        public static Socket chat_sck;  //用于聊天窗口通信的套接字

        //群聊结构体
        public struct GroupFri
        {
            public string id;
            public string ip;
            public int state;
            //public int ifleader;
        }
        public static List<Socket> groupSocket = new List<Socket>();
        public static List<GroupFri> groupFris = new List<GroupFri>();
        public static List<List<Socket>> gSL = new List<List<Socket>>();
        public static List<List<GroupFri>> gFL = new List<List<GroupFri>>();
    }
}
