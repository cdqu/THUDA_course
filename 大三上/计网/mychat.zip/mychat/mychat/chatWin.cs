﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;

namespace mychat
{
    public partial class chatWin : Form
    {
        public chatWin(string id, string ip, Socket sck)
        {
            InitializeComponent();
            mess_id = id;  //学号
            mess_ip = ip;  //ip
            chat_sck = sck;
        }

        string mess_id;  //发送消息者学号
        string mess_ip;  //ip
        string mess_t;  //消息类型
        Socket chat_sck;  //聊天套接字

        //定义发送数据缓存
        public byte[] senddata = new byte[1024];
        //定义字符串，用于控制台输出或输入
        public string input, stringData;
        //定义新线程
        Thread th;
        //定义发送消息类型：文本0 文件1
        int type;

        private void chatWin_Load(object sender, EventArgs e)
        {
            //开启一个新线程接收消息
            th = new Thread(Recive);
            th.IsBackground = true;
            th.Start();
            if (!Global.IPpool.Contains(mess_ip))
            {
                chat_sck = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            }
            else
            { }
            //初始类型为文本
            type = 0;
            //导入聊天记录，若没有，新建txt
            if (File.Exists(mess_id + ".txt"))
            {
                StreamReader sr = File.OpenText(mess_id + ".txt");
                string nextLine;
                while ((nextLine = sr.ReadLine()) != null)
                {
                    rtb_chat.AppendText(nextLine + "\n");
                }
                sr.Close();
                rtb_chat.AppendText("<以上是历史消息>" + "\n");
            }
            else  //不存在则创建文件
            {
                FileStream fs = new FileStream(mess_id + ".txt", FileMode.Create, FileAccess.Write);
                fs.Close();
            }
        }


        //不断接收消息
        void Recive()
        {
            while (true)
            {
                try
                {
                    byte[] buffer = new byte[1024 * 1024];
                    int r = chat_sck.Receive(buffer);
                    //实际接收到的有效字节数
                    if (r == 0)
                    {
                        break;
                    }
                    mess_id = Encoding.UTF8.GetString(buffer, 0, 10);
                    mess_t = Encoding.ASCII.GetString(buffer, 10, 1);
                    if (mess_t == "0")  //接收到文本
                    {
                        string s = Encoding.UTF8.GetString(buffer, 11, r - 11);
                        if (s == "BYE")  //对方下线
                        {
                            //显示消息
                            Action<string> action = (mess) =>
                            {
                                rtb_chat.AppendText(mess_id + " " + DateTime.Now.ToLocalTime().ToString() + "\n" + mess + "\n");
                                rtb_chat.AppendText("<对方已下线>" + "\n");
                                rtb_chat.Focus();
                                //设置光标的位置到文本尾  
                                rtb_chat.Select(rtb_chat.TextLength, 0);
                                //滚动到控件光标处  
                                rtb_chat.ScrollToCaret();
                                //光标换至发送框
                                txt_send.Focus();
                            };
                            Invoke(action, s);
                            //关闭退出
                            try
                            {
                                //关闭套接字、移除Ip信息
                                Global.IPpool.Remove(mess_ip);
                                th.Abort();
                                chat_sck.Shutdown(SocketShutdown.Both);
                                chat_sck.Close();
                            }
                            catch { }
                        }
                        else
                        {
                            //显示消息
                            Action<string> action = (mess) =>
                            {
                                rtb_chat.AppendText(mess_id + " " + DateTime.Now.ToLocalTime().ToString() + "\n" + mess + "\n");
                                rtb_chat.Focus();
                                //设置光标的位置到文本尾  
                                rtb_chat.Select(rtb_chat.TextLength, 0);
                                //滚动到控件光标处  
                                rtb_chat.ScrollToCaret();
                                //光标换至发送框
                                txt_send.Focus();
                            };
                            Invoke(action, s);
                        }
                    }
                    else if (mess_t == "1")  //接收到文件
                    {
                        //读取文件名和文件长度
                        string s = Encoding.UTF8.GetString(buffer, 11, r - 11);
                        int pos = s.IndexOf('|');
                        int end = s.Length - 1;
                        string fn = s.Substring(0, pos);
                        long fl = long.Parse(s.Substring(pos + 1));

                        //确认接收
                        if (DialogResult.OK == MessageBox.Show("对方向您发送文件" + fn + "是否接收？", "提示", MessageBoxButtons.OKCancel))
                        {
                            int firstRcv = chat_sck.Receive(buffer);//获取客户端信息
                            string path = "";
                            SaveFileDialog save = new SaveFileDialog();//创建SaveFileDialog实例

                            Action<SaveFileDialog> action1 = (sd) =>
                            {
                                sd.FileName = fn;
                                if (sd.ShowDialog() == DialogResult.OK)//按下确定选择的按钮
                                {
                                    path = sd.FileName.ToString();
                                }
                            };
                            Invoke(action1, save);
                            bool firstWrite = true;
                            int rec = 0;//定义获取接受数据的长度初始值
                            long recFileLength = 0;
                            FileStream filesave = new FileStream(path, FileMode.Create, FileAccess.Write);//创建文件流，用来写入数据
                            while (recFileLength < fl)//判断读取文件长度是否小于总文件长度
                            {
                                if (firstWrite)//第一次写入时
                                {
                                    filesave.Write(buffer, 1, firstRcv - 1);//截取字节数据写入文件中
                                    filesave.Flush();//清空缓存信息
                                    recFileLength += firstRcv - 1;//记录已获取的数据大小
                                    firstWrite = false;//切换状态
                                }
                                else
                                {
                                    rec = chat_sck.Receive(buffer);//继续接收文件并存入缓存
                                    filesave.Write(buffer, 0, rec);//将缓存中的数据写入文件中
                                    filesave.Flush();//清空缓存信息
                                    recFileLength += rec;//继续记录已获取的数据大小
                                }
                                Console.WriteLine("{0}: 已接收数据：{1}/{2}", chat_sck.RemoteEndPoint, recFileLength, fl);//查看已接受数据进度
                            }
                            filesave.Close();
                            Console.WriteLine("保存成功！！！");
                            Action<string> action = (mess) =>
                            {
                                rtb_chat.AppendText(mess_id + " " + DateTime.Now.ToLocalTime().ToString() + "\n" + "成功接收" + mess + "\n");
                                rtb_chat.Focus();
                                //设置光标的位置到文本尾  
                                rtb_chat.Select(rtb_chat.TextLength, 0);
                                //滚动到控件光标处  
                                rtb_chat.ScrollToCaret();
                                //光标换至发送框
                                txt_send.Focus();
                            };
                            Invoke(action, fn);
                        }
                    }
                }
                catch { }
            }
        }

        //关闭
        private void chatWin_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                //向对方发送下线通知
                chat_sck.Send(Encoding.ASCII.GetBytes(Global.myid + "0BYE"));
                //关闭套接字、移除Ip信息
                Global.IPpool.Remove(mess_ip);
                th.Abort();
                chat_sck.Shutdown(SocketShutdown.Both);
                chat_sck.Close();
                //存入聊天记录
                FileStream fs = new FileStream(mess_id + ".txt", FileMode.Create, FileAccess.Write);
                StreamWriter wr = null;
                wr = new StreamWriter(fs);
                wr.WriteLine(rtb_chat.Text);
                wr.Close();
                fs.Close();
            }
            catch { }
        }

        string fileN;  //发送文件名
        FileStream fs; //文件流
        //选择文件
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();//创建OpenFileDialog实例，方便打开选取文件对话框
            open.Multiselect = false;//是否允许多选
            if (open.ShowDialog() == DialogResult.OK)//按下确定选择的按钮
            {
                type = 1;  //类型改为发送文件
                string fileName = open.FileName;  //获取选取文件的文件路径及文件名
                fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);//创建文件流，用来读取数据
                fileN = Path.GetFileName(fileName);//提取文件名
                txt_send.Text = fileName;
            }
        }

        private void btn_send_Click(object sender, EventArgs e)  //发送会话
        {
            if (txt_send.Text != "")  //发送会话不为空
            {
                if (!chat_sck.Connected)  //未连接
                {
                    //定义主机的IP及端口
                    IPAddress ip = IPAddress.Parse(mess_ip);
                    IPEndPoint ipEnd = new IPEndPoint(ip, 5566);
                    //尝试连接
                    try
                    {
                        chat_sck.Connect(ipEnd);
                        Global.IPpool.Add(mess_ip);
                        senddata = Encoding.UTF8.GetBytes(Global.myid + "0");
                        chat_sck.Send(senddata, senddata.Length, SocketFlags.None);
                    }
                    catch (SocketException exc)
                    {
                        Console.Write("Fail to connect server");
                        return;
                    }
                }
                if (type == 0) //发送文本消息
                {
                    input = txt_send.Text;
                    txt_send.Text = "";
                    //将从键盘获取的字符串转换成整型数据并存储在数组中    
                    senddata = Encoding.UTF8.GetBytes(Global.myid + '0' + input);
                    //发送该数组
                    if (chat_sck.Send(senddata, senddata.Length, SocketFlags.None) == senddata.Length)  //发送成功
                    {
                        rtb_chat.AppendText("me " + DateTime.Now.ToLocalTime().ToString() + "\n" + input + "\n");  //新添一行                                                                                                               //让文本框获取焦点  
                        rtb_chat.Focus();
                        //设置光标的位置到文本尾  
                        rtb_chat.Select(rtb_chat.TextLength, 0);
                        //滚动到控件光标处  
                        rtb_chat.ScrollToCaret();
                        //光标换至发送框
                        txt_send.Focus();
                    }
                }
                else if (type == 1)  //发送文件
                {

                    long fileL = fs.Length;  //获取文件长度
                    senddata = Encoding.UTF8.GetBytes(Global.myid + '1' + fileN + "|" + fileL);
                    int readLength = 0;  //已读长度
                    int sentFileLength = 0;  //已发送长度
                    bool firstRead = true;  //是否是第一个数据包
                    if (chat_sck.Send(senddata, senddata.Length, SocketFlags.None) == senddata.Length)  //发送成功
                    {

                        byte[] arrFile = new byte[1024 * 1024];
                        readLength = fs.Read(arrFile, 0, 1024 * 1024 - 1);

                        while (readLength > 0 && sentFileLength < fileL)
                        {
                            if (firstRead)
                            {
                                sentFileLength += readLength;
                                byte[] firstBuffer = new byte[readLength + 1];//这个操作同样也是用来标记文件的
                                firstBuffer[0] = 2;//将第一个字节标记成2，代表为文件
                                Buffer.BlockCopy(arrFile, 0, firstBuffer, 1, readLength);//偏移复制字节数组
                                chat_sck.Send(firstBuffer, 0, readLength + 1, SocketFlags.None);
                                Console.WriteLine("第一次读取数据成功，在前面添加一个标记");//发送文件数据包
                                firstRead = false;//切换状态，避免再次进入
                                continue;
                            }
                            readLength = fs.Read(arrFile, 0, 1024 * 1024);
                            sentFileLength += readLength;  //计算已读取文件大小
                            chat_sck.Send(arrFile, 0, readLength, SocketFlags.None);//继续发送剩下的数据包
                            Console.WriteLine("{0}: 已发送数据：{1}/{2}", chat_sck.RemoteEndPoint, sentFileLength, fileL);//查看发送进度
                        }
                        fs.Close();//关闭文件流
                        Console.WriteLine("发送完成");//提示发送完毕
                        txt_send.Text = "";
                        rtb_chat.AppendText("me " + DateTime.Now.ToLocalTime().ToString() + "\n" + fileN + "\n");  //新添一行
                        rtb_chat.Focus();
                        //设置光标的位置到文本尾  
                        rtb_chat.Select(rtb_chat.TextLength, 0);
                        //滚动到控件光标处  
                        rtb_chat.ScrollToCaret();
                        //光标换至发送框
                        txt_send.Focus();
                    }
                    else
                    {
                        MessageBox.Show("发送文件失败！");
                    }
                    type = 0;
                }
            }
            else
            { }
        }
    }
}
