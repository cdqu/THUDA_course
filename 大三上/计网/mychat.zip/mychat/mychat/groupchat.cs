﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;

namespace mychat
{
    public partial class groupchat : Form
    {
        public groupchat()
        {
            InitializeComponent();
        }

        byte[] senddata = new byte[1024];  //文本缓存
        byte[] buffer = new byte[1024 * 1024];  //文件缓存
        //定义字符串，用于控制台输出或输入
        string input;
        //定义线程list
        List<Thread> threads = new List<Thread>();
        //定义发送消息类型：文本0 文件1
        int type;

        //初始化
        private void groupchat_Load(object sender, EventArgs e)
        {
            //显示好友名单
            for (int i = 0; i < Global.groupFris.Count; i++)
            {
                rtb_fris.AppendText(Global.groupFris[i].id + "\n");
            }
            //为每个套接字建立线程
            for (int i = 0; i < Global.groupSocket.Count; i++)
            {
                Thread th = new Thread(Recive);
                th.IsBackground = true;
                th.Start(Global.groupSocket[i]);
                threads.Add(th);
            }
        }

        string mess_id;  //发送消息者学号
        string mess_t;  //消息类型
        //不断接收消息
        void Recive(object o)
        {
            Socket socketWatch = o as Socket;
            while (true)
            {
                try
                {
                    byte[] recdata = new byte[1024];
                    int r = socketWatch.Receive(recdata);
                    //实际接收到的有效字节数
                    if (r == 0)
                    {
                        break;
                    }
                    mess_id = Encoding.UTF8.GetString(recdata, 0, 10);
                    mess_t = Encoding.UTF8.GetString(recdata, 10, 1);
                    if (mess_t == "0")  //接收到文本
                    {
                        string s = Encoding.UTF8.GetString(recdata, 11, r - 11);
                        //显示消息
                        Action<string> action = (mess) =>
                        {
                            rtb_mess.AppendText(mess_id + " " + DateTime.Now.ToLocalTime().ToString() + "\n" + mess + "\n");
                            rtb_mess.Focus();
                            //设置光标的位置到文本尾  
                            rtb_mess.Select(rtb_mess.TextLength, 0);
                            //滚动到控件光标处  
                            rtb_mess.ScrollToCaret();
                            //光标换至发送框
                            txt_gc.Focus();
                        };
                        Invoke(action, s);
                    }
                    else if (mess_t == "1")  //接收到文件
                    {
                        //读取文件名和文件长度
                        string s = Encoding.UTF8.GetString(recdata, 11, r - 11);
                        int pos = s.IndexOf('|');
                        int end = s.Length - 1;
                        string fn = s.Substring(0, pos);
                        long fl = long.Parse(s.Substring(pos + 1));

                        //确认接收
                        if (DialogResult.OK == MessageBox.Show("组员向您发送文件" + fn + "是否接收？", "提示", MessageBoxButtons.OKCancel))
                        {
                            int firstRcv = socketWatch.Receive(buffer);//获取客户端信息
                            string path = "";
                            SaveFileDialog save = new SaveFileDialog();//创建SaveFileDialog实例

                            Action<SaveFileDialog> action1 = (sd) =>
                            {
                                sd.FileName = fn;
                                if (sd.ShowDialog() == DialogResult.OK)//按下确定选择的按钮
                                {
                                    path = sd.FileName.ToString();
                                }
                            };
                            Invoke(action1, save);
                            bool firstWrite = true;
                            int rec = 0;//定义获取接受数据的长度初始值
                            long recFileLength = 0;
                            FileStream filesave = new FileStream(path, FileMode.Create, FileAccess.Write);//创建文件流，用来写入数据
                            while (recFileLength < fl)//判断读取文件长度是否小于总文件长度
                            {
                                if (firstWrite)//第一次写入时
                                {
                                    filesave.Write(buffer, 1, firstRcv - 1);//截取字节数据写入文件中
                                    filesave.Flush();//清空缓存信息
                                    recFileLength += firstRcv - 1;//记录已获取的数据大小
                                    firstWrite = false;//切换状态
                                }
                                else
                                {
                                    rec = socketWatch.Receive(buffer);//继续接收文件并存入缓存
                                    filesave.Write(buffer, 0, rec);//将缓存中的数据写入文件中
                                    filesave.Flush();//清空缓存信息
                                    recFileLength += rec;//继续记录已获取的数据大小
                                }
                                Console.WriteLine("{0}: 已接收数据：{1}/{2}", socketWatch.RemoteEndPoint, recFileLength, fl);//查看已接受数据进度
                            }
                            filesave.Close();
                            Console.WriteLine("保存成功！！！");
                            Action<string> action = (mess) =>
                            {
                                rtb_mess.AppendText(Global.friip + " " + DateTime.Now.ToLocalTime().ToString() + "\n" + "已保存" + mess + "\n");
                                rtb_mess.Focus();
                                //设置光标的位置到文本尾  
                                rtb_mess.Select(rtb_mess.TextLength, 0);
                                //滚动到控件光标处  
                                rtb_mess.ScrollToCaret();
                                //光标换至发送框
                                txt_gc.Focus();
                            };
                            Invoke(action, fn);
                        }
                    }
                }
                catch { }
            }
        }

        private void groupchat_FormClosing(object sender, FormClosingEventArgs e)
        {
            //关线程
            for (int i = 0; i < threads.Count; i++)
            {
                threads[i].Abort();
            }
            threads.Clear();
            //关套接字
            for (int i = 0; i < Global.groupSocket.Count; i++)
            {
                Global.groupSocket[i].Shutdown(SocketShutdown.Both);
                Global.groupSocket[i].Close();
            }
            Global.groupSocket.Clear();
            //清群聊list
            Global.groupFris.Clear();
        }

        string fileN;  //发送文件名
        string fileName;
        //选择文件
        private void btn_file_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();//创建OpenFileDialog实例，方便打开选取文件对话框
            open.Multiselect = false;//是否允许多选
            if (open.ShowDialog() == DialogResult.OK)//按下确定选择的按钮
            {
                type = 1;  //类型改为发送文件
                fileName = open.FileName;  //获取选取文件的文件路径及文件名
                //fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);//创建文件流，用来读取数据
                fileN = Path.GetFileName(fileName);//提取文件名
                txt_gc.Text = fileName;
            }
        }

        //发送
        private void button1_Click(object sender, EventArgs e)
        {
            if (txt_gc.Text != "")  //发送会话不为空
            {
                if (type == 0)  //文字消息
                {
                    input = txt_gc.Text;
                    txt_gc.Text = "";

                    //向所有套接字发送该数组
                    for (int i = 0; i < Global.groupSocket.Count; i++)
                    {
                        try
                        {
                            senddata = Encoding.UTF8.GetBytes(Global.myid + '0' + input);
                            Global.groupSocket[i].Send(senddata);
                        }
                        catch { }
                    }
                    rtb_mess.AppendText("me " + DateTime.Now.ToLocalTime().ToString() + "\n" + input + "\n");  //新添一行
                    rtb_mess.Focus();
                    //设置光标的位置到文本尾  
                    rtb_mess.Select(rtb_mess.TextLength, 0);
                    //滚动到控件光标处  
                    rtb_mess.ScrollToCaret();
                    //光标换至发送框
                    txt_gc.Focus();
                }
                else if (type == 1)  //发送文件
                {

                    for (int i = 0; i < Global.groupSocket.Count; i++)
                    {
                        FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                        long fileL = fs.Length;  //获取文件长度
                        senddata = Encoding.UTF8.GetBytes(Global.myid + '1' + fileN + "|" + fileL);
                        int readLength = 0;  //已读长度
                        int sentFileLength = 0;  //已发送长度
                        bool firstRead = true;  //是否是第一个数据包
                        if (Global.groupSocket[i].Send(senddata, senddata.Length, SocketFlags.None) == senddata.Length)  //发送成功
                        {
                            byte[] arrFile = new byte[1024 * 1024];
                            readLength = fs.Read(arrFile, 0, 1024 * 1024 - 1);

                            while (readLength > 0 && sentFileLength < fileL)
                            {
                                if (firstRead)
                                {
                                    sentFileLength += readLength;
                                    byte[] firstBuffer = new byte[readLength + 1];//这个操作同样也是用来标记文件的
                                    firstBuffer[0] = 2;//将第一个字节标记成2，代表为文件
                                    Buffer.BlockCopy(arrFile, 0, firstBuffer, 1, readLength);//偏移复制字节数组
                                    Global.groupSocket[i].Send(firstBuffer, 0, readLength + 1, SocketFlags.None);
                                    Console.WriteLine("第一次读取数据成功，在前面添加一个标记");//发送文件数据包
                                    firstRead = false;//切换状态，避免再次进入
                                    continue;
                                }
                                readLength = fs.Read(arrFile, 0, 1024 * 1024);
                                sentFileLength += readLength;  //计算已读取文件大小
                                Global.groupSocket[i].Send(arrFile, 0, readLength, SocketFlags.None);//继续发送剩下的数据包
                                Console.WriteLine("{0}: 已发送数据：{1}/{2}", Global.groupSocket[i].RemoteEndPoint, sentFileLength, fileL);//查看发送进度
                            }
                            fs.Close();//关闭文件流
                        }
                        else
                        {
                            MessageBox.Show("发送文件失败！");
                        }
                    }

                    Console.WriteLine("发送完成");//提示发送完毕
                    txt_gc.Text = "";
                    rtb_mess.AppendText("me " + DateTime.Now.ToLocalTime().ToString() + "\n" + fileN + "\n");  //新添一行
                    rtb_mess.Focus();
                    //设置光标的位置到文本尾  
                    rtb_mess.Select(rtb_mess.TextLength, 0);
                    //滚动到控件光标处  
                    rtb_mess.ScrollToCaret();
                    //光标换至发送框
                    txt_gc.Focus();
                    type = 0;
                }
                else { }
            }
        }
    }
}
