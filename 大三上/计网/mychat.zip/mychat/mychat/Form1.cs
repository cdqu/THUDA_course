﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace mychat
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private static byte[] recbuff = new byte[1024];  //创建字节数组

        private void btn_load_Click(object sender, EventArgs e)  //登陆
        {
            //txt_id.Text="2017010928";
            Global.myid = txt_id.Text;  //学号
            //txt_code.Text = "net2019";
            string mycode = txt_code.Text;  //密码
            string lol_ask = Global.myid + "_" + mycode;  //登陆请求
            //创建与中央服务器连接的套接字
            Global.main_serv_sck = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            //服务器IP
            IPAddress ip = IPAddress.Parse("166.111.140.57");
            //连接
            try
            {
                Global.main_serv_sck.Connect(new IPEndPoint(ip, 8000));  //IP+端口号
                Console.WriteLine("连接服务器成功！");
            }
            catch
            {
                Console.WriteLine("连接服务器失败，请按回车键退出！");
                MessageBox.Show("连接服务器失败，请重试！", "登录提示");
                return;
            }
            //登陆请求
            Global.main_serv_sck.Send(Encoding.ASCII.GetBytes(lol_ask));
            int recLength = Global.main_serv_sck.Receive(recbuff);
            if (Encoding.ASCII.GetString(recbuff, 0, recLength) == "lol")  //登陆成功
            {
                Console.WriteLine("登陆成功!");
                //转至主界面
                this.Hide();
                mainWin mw = new mainWin();
                mw.ShowDialog(this);
                this.Close();
            }
            else
            {
                Console.WriteLine("登陆失败!");
                MessageBox.Show("登陆失败，请重试！", "登录提示");
            }
        }

        private void btn_leave_Click(object sender, EventArgs e)  //退出
        {
            this.Close();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
