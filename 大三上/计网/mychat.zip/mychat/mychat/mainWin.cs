﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace mychat
{
    public partial class mainWin : Form
    {
        //用于添加好友的套接字
        public Socket addfri_sck;

        public int recv, recLength;  //字节长度
        //定义接收数据的缓存
        public byte[] rcvdata = new byte[1024];
        byte[] recbuff = new byte[1024];

        //定义侦听端口
        public IPEndPoint ipEnd = new IPEndPoint(IPAddress.Any, 5566);
        //定义server监听套接字
        public Socket ser_sck = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

        //发送群聊消息
        byte[] sendgrmess = new byte[1024];

        public mainWin()
        {
            InitializeComponent();
        }

        //好友结构体
        public struct MyFri
        {
            public string stuID;
            public string IP;
        }

        List<MyFri> myfri = new List<MyFri>();  //好友list

        private void mainWin_Load(object sender, EventArgs e)
        {
            lb_id.Text = Global.myid;

            lv_fri.View = View.Details;
            //读入好友数据
            if (File.Exists("myfri.txt"))
            {
                StreamReader sr_s = File.OpenText("myfri.txt");
                string nextLine;
                int pos, end;
                while ((nextLine = sr_s.ReadLine()) != null)
                {
                    pos = nextLine.IndexOf(' ');
                    end = nextLine.Length - 1;
                    MyFri myf = new MyFri();
                    myf.stuID = nextLine.Substring(0, pos);
                    myf.IP = nextLine.Substring(pos + 1);
                    myfri.Add(myf);
                }
                sr_s.Close();

                //添加Listview
                this.lv_fri.BeginUpdate();   //数据更新
                for (int i = 0; i < myfri.Count; i++)
                {
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = myfri[i].stuID;
                    Global.main_serv_sck.Send(Encoding.ASCII.GetBytes("q" + myfri[i].stuID));
                    recLength = Global.main_serv_sck.Receive(recbuff);
                    if(Encoding.ASCII.GetString(recbuff, 0, recLength)=="n")
                    {
                        lvi.SubItems.Add(myfri[i].IP);
                        lvi.SubItems.Add("离线");
                    }
                    else
                    {
                        lvi.SubItems.Add(Encoding.ASCII.GetString(recbuff, 0, recLength));
                        lvi.SubItems.Add("在线");
                    }
                    this.lv_fri.Items.Add(lvi);
                }
                this.lv_fri.EndUpdate();  //结束数据处理，UI界面一次性绘制。
            }
            else  //不存在则创建文件
            {
                FileStream fs1 = new FileStream("myfri.txt", FileMode.Create, FileAccess.Write);
                fs1.Close();
            }

            //开启服务器端监听
            //连接
            ser_sck.Bind(ipEnd);
            //开始侦听
            ser_sck.Listen(10);
            //控制台输出侦听状态
            Console.Write("Waiting for a client");
            //新开线程监听
            Thread th = new Thread(Listen);
            th.IsBackground = true;
            th.Start(ser_sck);
        }

        Socket cli_sck = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        //监听属性（监听消息类型：新消息、好友请求、好友请求回复）
        void Listen(object o)
        {
            Socket socketWatch = o as Socket;  //传入的监听套接字
            //等待客户端的连接 并且创建一个负责通信的Socket
            while (true)
            {
                try
                {
                    //负责跟客户端通信的Socket
                    cli_sck = socketWatch.Accept();
                    //接收消息
                    recLength = cli_sck.Receive(recbuff,11,SocketFlags.None);
                    //好友id
                    string id = Encoding.ASCII.GetString(recbuff, 0, 10);
                    //报头，是群聊邀请
                    if (Encoding.ASCII.GetString(recbuff, 10, 1) == "3")
                    {
                        //加入群聊套接字list
                        Global.groupSocket.Add(cli_sck);
                        //读取群聊基本信息
                        recLength = cli_sck.Receive(recbuff);
                        string grmess= Encoding.ASCII.GetString(recbuff);
                        int num = Convert.ToInt32(grmess.Substring(0, 1));  //群聊人数
                        string fid;  //好友id
                        string fip;  //好友ip
                        bool ifbehind = false;  //是否排在自己之后
                        for (int i = 0; i < num; i++)
                        {
                            //获取id
                            fid = grmess.Substring(10 * i + 1, 10);
                            if (fid != Global.myid)  //如果不是自己id
                            {
                                //查询获取ip
                                Global.main_serv_sck.Send(Encoding.ASCII.GetBytes("q" + fid));
                                recLength = Global.main_serv_sck.Receive(recbuff);
                                fip = Encoding.ASCII.GetString(recbuff, 0, recLength);
                                //添加到list
                                Global.GroupFri gf = new Global.GroupFri();
                                gf.id = fid;
                                gf.ip = fip;
                                gf.state = 1;
                                Global.groupFris.Add(gf);
                                //与排在自己之后的成员建立套接字
                                if (ifbehind)
                                {
                                    Socket new_sck = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                                    IPAddress ip = IPAddress.Parse(fip);
                                    IPEndPoint ipEnd = new IPEndPoint(ip, 5566);
                                    try
                                    {
                                        new_sck.Connect(ipEnd);
                                        Console.WriteLine("已建立1个套接字");
                                        sendgrmess = Encoding.ASCII.GetBytes(Global.myid+"3"+"0");  //将num置0，避免重复操作
                                        new_sck.Send(sendgrmess);
                                        Global.groupSocket.Add(new_sck);
                                    }
                                    catch { }
                                }
                            }
                            else  //是自己id，之后好友都要建立套接字
                            {
                                ifbehind = true;
                            }
                        }
                        //判断是否已与所有成员建立套接字
                        if(Global.groupFris.Count==Global.groupSocket.Count)
                        {
                            //把自己加入list
                            Global.GroupFri me = new Global.GroupFri();
                            me.id = Global.myid;
                            IPAddress ServerIp = Dns.GetHostEntry(Dns.GetHostName()).AddressList[0];
                            me.ip = ServerIp.ToString();
                            me.state = 1;
                            Global.groupFris.Insert(0, me);
                            //打开窗口
                            groupchat gc = null;
                            Action<groupchat> action = (newWin) =>  //委托
                            {
                                newWin = new groupchat();
                                newWin.Show(this);
                            };
                            Invoke(action, gc);
                        }                                               
                    }
                    else  //私聊
                    {
                        Global.chat_sck = cli_sck;
                        //获取好友IP
                        string IPmess = Global.chat_sck.RemoteEndPoint.ToString();
                        int ind = IPmess.IndexOf(':');
                        Global.friip = IPmess.Substring(0, ind);

                        //连接成功消息
                        Console.WriteLine(Global.chat_sck.RemoteEndPoint.ToString() + ":" + "连接成功");
                        //查看好友列表中是否存在此人
                        if (myfri.Count == 0)  //好友列表为空
                        {
                            recLength = Global.chat_sck.Receive(recbuff);
                            if (Encoding.ASCII.GetString(recbuff, 0, 6) == "addREQ")  //是好友添加请求
                            {
                                //同意，发送ACK
                                if (DialogResult.OK == MessageBox.Show(id + "请求添加为好友，是否同意？", "提示", MessageBoxButtons.OKCancel))
                                {
                                    addfri_sck = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                                    addfri_sck.Connect(new IPEndPoint(IPAddress.Parse(Global.friip), 5566));
                                    addfri_sck.Send(Encoding.ASCII.GetBytes(Global.myid + "0addACK"));
                                    MessageBox.Show("已添加为好友！");
                                    addfri_sck.Shutdown(SocketShutdown.Both);
                                    addfri_sck.Close();
                                    MyFri new_fri = new MyFri();
                                    new_fri.stuID = id;
                                    new_fri.IP = Global.friip;
                                    myfri.Add(new_fri);
                                    //添加Listview
                                    ListViewItem LVI = null;
                                    Action<ListViewItem, ListView> action = (lvi, lv) =>  //委托
                                    {
                                        lv.BeginUpdate();  //数据更新
                                        lv.Items.Clear();  //清空数据
                                        for (int j = 0; j < myfri.Count; j++)
                                        {
                                            lvi = new ListViewItem();
                                            lvi.Text = myfri[j].stuID;
                                            Global.main_serv_sck.Send(Encoding.ASCII.GetBytes("q" + myfri[j].stuID));
                                            recLength = Global.main_serv_sck.Receive(recbuff);
                                            if (Encoding.ASCII.GetString(recbuff, 0, recLength) == "n")
                                            {
                                                lvi.SubItems.Add(myfri[j].IP);
                                                lvi.SubItems.Add("离线");
                                            }
                                            else
                                            {
                                                lvi.SubItems.Add(Encoding.ASCII.GetString(recbuff, 0, recLength));
                                                lvi.SubItems.Add("在线");
                                            }

                                            lv.Items.Add(lvi);
                                        }
                                        lv.EndUpdate();  //结束数据处理，UI界面一次性绘制
                                    };
                                    Invoke(action, LVI, lv_fri);
                                }
                            }
                            else if (Encoding.ASCII.GetString(recbuff, 0, 6) == "addACK")  //是好友添加回复
                            {
                                MessageBox.Show("对方已添加你为好友！");
                          
                                MyFri new_fri = new MyFri();
                                new_fri.stuID = id;
                                new_fri.IP = Global.friip;
                                myfri.Add(new_fri);
                                //添加Listview
                                ListViewItem LVI = null;

                                Action<ListViewItem, ListView> action = (lvi, lv) =>  //委托
                                {
                                    lv.BeginUpdate();  //数据更新
                                    lv.Items.Clear();  //清空数据
                                    for (int j = 0; j < myfri.Count; j++)
                                    {
                                        lvi = new ListViewItem();
                                        lvi.Text = myfri[j].stuID;
                                        Global.main_serv_sck.Send(Encoding.ASCII.GetBytes("q" + myfri[j].stuID));
                                        recLength = Global.main_serv_sck.Receive(recbuff);
                                        if (Encoding.ASCII.GetString(recbuff, 0, recLength) == "n")
                                        {
                                            lvi.SubItems.Add(myfri[j].IP);
                                            lvi.SubItems.Add("离线");
                                        }
                                        else
                                        {
                                            lvi.SubItems.Add(Encoding.ASCII.GetString(recbuff, 0, recLength));
                                            lvi.SubItems.Add("在线");
                                        }

                                        lv.Items.Add(lvi);
                                    }
                                    lv.EndUpdate();  //结束数据处理，UI界面一次性绘制
                                };
                                Invoke(action, LVI, lv_fri);
                            }
                            else
                            { }

                        }
                        else  //不为空
                        {
                            bool ifexit = false;
                            for (int i = 0; i < myfri.Count; i++)
                            {
                                if (myfri[i].stuID == id)  //存在
                                {
                                    ifexit = true;
                                    break;
                                }
                            }
                            if (ifexit)
                            {
                                //是否已与其建立连接（IP池查找）
                                chatWin cw = null;
                                if (!Global.IPpool.Contains(Global.friip))
                                {
                                    Global.IPpool.Add(IPmess.Substring(0, ind));
                                    if (DialogResult.OK == MessageBox.Show("有新消息，是否查看？", "提示", MessageBoxButtons.OKCancel))
                                    {
                                        Action<chatWin> action = (newWin) =>  //委托
                                        {
                                            newWin = new chatWin(id,Global.friip,Global.chat_sck);
                                            newWin.Show(this);
                                        };
                                        Invoke(action, cw);
                                    }
                                   
                                }
                            }
                            else  //不存在，看是否为好友添加请求
                            {
                                recLength = Global.chat_sck.Receive(recbuff);
                                if (Encoding.ASCII.GetString(recbuff, 0, 6) == "addREQ")  //是好友添加请求
                                {
                                    //同意，发送ACK
                                    if (DialogResult.OK == MessageBox.Show(id + "请求添加为好友，是否同意？", "提示", MessageBoxButtons.OKCancel))
                                    {
                                        addfri_sck = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                                        addfri_sck.Connect(new IPEndPoint(IPAddress.Parse(Global.friip), 5566));
                                        addfri_sck.Send(Encoding.ASCII.GetBytes(Global.myid + "0addACK"));
                                        MessageBox.Show("已添加为好友！");
                                        addfri_sck.Shutdown(SocketShutdown.Both);
                                        addfri_sck.Close();
                                        MyFri new_fri = new MyFri();
                                        new_fri.stuID = id;
                                        new_fri.IP = Global.friip;
                                        myfri.Add(new_fri);
                                        //添加Listview
                                        ListViewItem LVI = null;
                                        Action<ListViewItem, ListView> action = (lvi, lv) =>  //委托
                                        {
                                            lv.BeginUpdate();  //数据更新
                                            lv.Items.Clear();  //清空数据
                                            for (int j = 0; j < myfri.Count; j++)
                                            {
                                                lvi = new ListViewItem();
                                                lvi.Text = myfri[j].stuID;
                                                Global.main_serv_sck.Send(Encoding.ASCII.GetBytes("q" + myfri[j].stuID));
                                                recLength = Global.main_serv_sck.Receive(recbuff);
                                                if (Encoding.ASCII.GetString(recbuff, 0, recLength) == "n")
                                                {
                                                    lvi.SubItems.Add(myfri[j].IP);
                                                    lvi.SubItems.Add("离线");
                                                }
                                                else
                                                {
                                                    lvi.SubItems.Add(Encoding.ASCII.GetString(recbuff, 0, recLength));
                                                    lvi.SubItems.Add("在线");
                                                }

                                                lv.Items.Add(lvi);
                                            }
                                            lv.EndUpdate();  //结束数据处理，UI界面一次性绘制
                                            };
                                        Invoke(action, LVI, lv_fri);
                                       
                                    }
                                    else  //忽视
                                    { }
                                }
                                else if (Encoding.ASCII.GetString(recbuff, 0, 6) == "addACK")  //是好友添加回复
                                {
                                    MessageBox.Show("对方已添加你为好友！");
                               
                                    MyFri new_fri = new MyFri();
                                    new_fri.stuID = id;
                                    new_fri.IP = Global.friip;
                                    myfri.Add(new_fri);
                                    //添加Listview
                                    ListViewItem LVI = null;
                                    Action<ListViewItem, ListView> action = (lvi, lv) =>  //委托
                                    {
                                        lv.BeginUpdate();  //数据更新
                                            lv.Items.Clear();  //清空数据
                                        for (int j = 0; j < myfri.Count; j++)
                                        {
                                            lvi = new ListViewItem();
                                            lvi.Text = myfri[j].stuID;
                                            Global.main_serv_sck.Send(Encoding.ASCII.GetBytes("q" + myfri[j].stuID));
                                            recLength = Global.main_serv_sck.Receive(recbuff);
                                            if (Encoding.ASCII.GetString(recbuff, 0, recLength) == "n")
                                            {
                                                lvi.SubItems.Add(myfri[j].IP);
                                                lvi.SubItems.Add("离线");
                                            }
                                            else
                                            {
                                                lvi.SubItems.Add(Encoding.ASCII.GetString(recbuff, 0, recLength));
                                                lvi.SubItems.Add("在线");
                                            }

                                            lv.Items.Add(lvi);
                                        }
                                        lv.EndUpdate();  //结束数据处理，UI界面一次性绘制
                                        };
                                    Invoke(action, LVI, lv_fri);
                                  
                                }
                                else
                                { }
                            }
                            
                        }
                    }
                }
                catch
                { }
            }
        }


        private void button1_Click(object sender, EventArgs e)  //退出
        {
            string loo_ask = "logout" + Global.myid;  //下线请求
            Global.main_serv_sck.Send(Encoding.ASCII.GetBytes(loo_ask));

            recLength = Global.main_serv_sck.Receive(recbuff);
            Console.WriteLine(Encoding.ASCII.GetString(recbuff, 0, recLength));
            //关闭套接字
            Global.main_serv_sck.Shutdown(SocketShutdown.Both);
            Global.main_serv_sck.Close();
            //ser_sck.Shutdown(SocketShutdown.Both);
            //ser_sck.Close();

            this.Close();
            //写入好友列表txt
            FileStream fs = new FileStream("myfri.txt", FileMode.Create, FileAccess.Write);
            StreamWriter wr = null;
            wr = new StreamWriter(fs);
            string mess;
            for (int i = 0; i < myfri.Count; i++)
            {
                mess = myfri[i].stuID + " " + myfri[i].IP;
                wr.WriteLine(mess);
            }
            wr.Close();
            fs.Close();
        }

        private void lv_fri_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_startchat_Click(object sender, EventArgs e)  //点击好友列表发起对话
        {
            if (lv_fri.SelectedItems.Count != 1)
            {
                MessageBox.Show("请选择好友！");
            }
            else
            {
                string askid = lv_fri.SelectedItems[0].SubItems[0].Text;  //好友查询请求
                Global.main_serv_sck.Send(Encoding.ASCII.GetBytes("q" + askid));
                int recLength = Global.main_serv_sck.Receive(recbuff);
                if (Encoding.ASCII.GetString(recbuff, 0, recLength) == "n")  //"n"不在线
                {
                    MessageBox.Show("好友不在线哦~");
                }
                else  //在线
                {
                    Global.friip = Encoding.ASCII.GetString(recbuff, 0, recLength);
                    lv_fri.SelectedItems[0].SubItems[1].Text = Global.friip;
                    chatWin cw = new chatWin(askid,Global.friip,null);
                    cw.Show(this);
                }
            }
        }

        //群聊
        private void btn_groupchat_Click(object sender, EventArgs e)
        {
            if (lv_fri.SelectedItems.Count >= 1)  //选择好友人数
            {
                //查询好友是否在线，均在线则加入list
                for(int i=0;i<lv_fri.SelectedItems.Count;i++)
                {
                    Global.main_serv_sck.Send(Encoding.ASCII.GetBytes("q" + lv_fri.SelectedItems[i].SubItems[0].Text));
                    int recLength = Global.main_serv_sck.Receive(recbuff);
                    if (Encoding.ASCII.GetString(recbuff, 0, recLength) == "n")  //"n"不在线
                    {
                        MessageBox.Show(lv_fri.SelectedItems[i].SubItems[0].Text+"不在线哦~");  //有好友不在线，无法创建群聊
                        Global.groupFris.Clear();  //取消此次群聊
                        return;
                    }
                    //在线，加入群聊list
                    Global.GroupFri groupFri = new Global.GroupFri();
                    groupFri.id = lv_fri.SelectedItems[i].SubItems[0].Text;
                    groupFri.ip = Encoding.ASCII.GetString(recbuff, 0, recLength);
                    groupFri.state = 1;
                    Global.groupFris.Add(groupFri);
                }
                //把自己加入list
                Global.GroupFri me = new Global.GroupFri();
                me.id = Global.myid;
                IPAddress ServerIp = Dns.GetHostEntry(Dns.GetHostName()).AddressList[1];
                me.ip = ServerIp.ToString();
                me.state = 1;
                Global.groupFris.Insert(0, me);
                //群聊邀请消息 id+报头'3'+人数+群成员id
                string gr_mess = Global.myid+"3"+Convert.ToString(Global.groupFris.Count);  //id+报头+人数
                for (int i = 0; i < Global.groupFris.Count; i++)
                {
                    gr_mess = gr_mess + Global.groupFris[i].id;
                }

                //与所有群聊好友建立套接字，发送群聊信息
                for (int i = 1; i < Global.groupFris.Count; i++)
                {
                    Socket new_sck = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    IPAddress ip = IPAddress.Parse(Global.groupFris[i].ip);
                    IPEndPoint ipEnd = new IPEndPoint(ip, 5566);
                    try
                    {
                        new_sck.Connect(ipEnd);
                        Console.WriteLine("已建立1个套接字");
                        sendgrmess = Encoding.ASCII.GetBytes(gr_mess);
                        new_sck.Send(sendgrmess);
                        Global.groupSocket.Add(new_sck);
                    }
                    catch { }
                }

                //打开窗口
                groupchat gc = new groupchat();
                gc.Show(this);
            }
            else
            {
                MessageBox.Show("请选择好友！");
            }
        }

        //删除好友
        private void btn_dele_Click(object sender, EventArgs e)
        {
            if (lv_fri.SelectedItems.Count != 0)  //选择好友人数
            {
                //从listview和myfri<list>中移除
                for (int i = 0; i < lv_fri.SelectedItems.Count; i++)
                {

                    for (int j = 0; j < myfri.Count; j++)
                    {
                        if (myfri[j].stuID == lv_fri.SelectedItems[i].SubItems[0].Text)
                        {
                            myfri.Remove(myfri[j]);
                            break;
                        }
                    }
                    lv_fri.Items.Remove(lv_fri.SelectedItems[i]);
                }
            }
            else
            {
                MessageBox.Show("请选择好友！");
            }
        }

        //好友状态刷新
        private void btn_ref_Click(object sender, EventArgs e)
        {
            //添加Listview
            this.lv_fri.BeginUpdate();
            this.lv_fri.Items.Clear();
            for (int i = 0; i < myfri.Count; i++)
            {
                ListViewItem lvi = new ListViewItem();
                lvi.Text = myfri[i].stuID;
                Global.main_serv_sck.Send(Encoding.ASCII.GetBytes("q" + myfri[i].stuID));
                recLength = Global.main_serv_sck.Receive(recbuff);
                if (Encoding.ASCII.GetString(recbuff, 0, recLength) == "n")
                {
                    lvi.SubItems.Add(myfri[i].IP);
                    lvi.SubItems.Add("离线");
                }
                else
                {
                    lvi.SubItems.Add(Encoding.ASCII.GetString(recbuff, 0, recLength));
                    lvi.SubItems.Add("在线");
                }
                this.lv_fri.Items.Add(lvi);
            }
            this.lv_fri.EndUpdate();
        }

        private void button2_Click(object sender, EventArgs e)  //查询
        {
            if (txt_askid.Text == "")
            {
                MessageBox.Show("请输入希望查询的好友学号！");
            }
            else
            {
                string askid = txt_askid.Text;  //好友查询请求
                Global.main_serv_sck.Send(Encoding.ASCII.GetBytes("q" + askid));
                int recLength = Global.main_serv_sck.Receive(recbuff);
                if (Encoding.ASCII.GetString(recbuff, 0, recLength) == "n")  //"n"不在线
                {
                    MessageBox.Show("好友不在线哦~");
                }
                else  //在线
                {
                    Global.friip = Encoding.ASCII.GetString(recbuff, 0, recLength);

                    //查看好友列表中是否存在此人
                    if (myfri.Count == 0)  //好友列表为空
                    {
                        if (DialogResult.OK == MessageBox.Show("还不是好友，是否添加好友？", "提示", MessageBoxButtons.OKCancel))
                        {

                            try
                            {
                                IPAddress ip = IPAddress.Parse(Global.friip);
                                addfri_sck = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                                addfri_sck.Connect(new IPEndPoint(ip, 5566));
                                addfri_sck.Send(Encoding.ASCII.GetBytes(Global.myid+"0addREQ"));
                                MessageBox.Show("已发送好友请求！");
                                addfri_sck.Shutdown(SocketShutdown.Both);
                                addfri_sck.Close();
                            }
                            catch
                            {
                                MessageBox.Show("添加好友失败！");
                                return;
                            }
                        }
                    }
                    else  //不为空
                    {
                        bool ifexit = false;
                        for (int i = 0; i < myfri.Count; i++)
                        {
                            if (myfri[i].stuID == askid)  //存在，是否开启聊天
                            {
                                ifexit = true;
                                break;
                            }
                        }
                        if (ifexit)
                        {
                            if (DialogResult.OK == MessageBox.Show("好友在线，是否聊天？", "提示", MessageBoxButtons.OKCancel))
                            {
                                chatWin cw = new chatWin(askid,Global.friip,null);
                                cw.Show(this);
                            }
   
                        }
                        else  //不存在，看是否添加为好友
                        {
                            if (DialogResult.OK == MessageBox.Show("还不是好友，是否添加好友？", "提示", MessageBoxButtons.OKCancel))
                            {
                                try
                                {
                                    IPAddress ip = IPAddress.Parse(Global.friip);
                                    addfri_sck = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                                    addfri_sck.Connect(new IPEndPoint(ip, 5566));
                                    addfri_sck.Send(Encoding.ASCII.GetBytes(Global.myid + "0addREQ"));
                                    MessageBox.Show("已发送好友请求！");
                                    addfri_sck.Shutdown(SocketShutdown.Both);
                                    addfri_sck.Close();
                                }
                                catch
                                {
                                    MessageBox.Show("添加好友失败！");
                                    return;
                                }
                            }
                        }
                        
                    }
                }
            }
        }
    }
}
