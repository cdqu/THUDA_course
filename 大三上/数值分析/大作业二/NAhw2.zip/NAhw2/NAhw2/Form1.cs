﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NAhw2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_solve_Click(object sender, EventArgs e)
        {
            SIN sin = new SIN();
            double x = Convert.ToDouble(tbx_x.Text);
            //泰勒展开
            lbl_tay.Text=Convert.ToString(sin.taylor(x)[0]);
            lbl_taydel.Text = Convert.ToString(sin.myabs(sin.taylor(x)[0] - Math.Sin(x)));
            lbl_taynum.Text= Convert.ToString(sin.taylor(x)[1]);
            //变形欧拉
            double theta;
            int i;
            double j;
            if (x >= Math.PI / 2 || x <= -Math.PI / 2)  //超限，根据周期转换
            {
                theta = x * 180 / Math.PI;
                double x_ = x;
                if (x < 0)
                {
                    theta = -theta;
                }
                i = Convert.ToInt32(Math.Floor(theta / 90));
                j = theta % 90;
                i = i % 4;
                switch (i)
                {
                    case 0:
                        x = j / 180 * Math.PI;
                        break;
                    case 1:
                        x = (90 - j) / 180 * Math.PI;
                        break;
                    case 2:
                        x = -j / 180 * Math.PI;
                        break;
                    case 3:
                        x = -(90 - j) / 180 * Math.PI;
                        break;

                }
                if (x_ < 0)
                {
                    x = -x;
                }
            }
            
            if (sin.myabs(x) <= Math.PI / 4)  //转到[0,pi/4]
            {
                lbl_ae.Text = Convert.ToString(sin.Ad_Euler(x)[0]);
                lbl_aedel.Text= Convert.ToString(sin.Ad_Euler(x)[0]-Math.Sin(x));
            }
            else
            {
                if (x > 0)
                {
                    lbl_ae.Text = Convert.ToString(sin.mysqrt(1 - sin.Ad_Euler(Math.PI / 2 - x)[0] * sin.Ad_Euler(Math.PI / 2 - x)[0]));
                    lbl_aedel.Text= Convert.ToString(sin.mysqrt(1 - sin.Ad_Euler(Math.PI / 2 - x)[0] * sin.Ad_Euler(Math.PI / 2 - x)[0])-Math.Sin(x));
                }
                else
                {
                    lbl_ae.Text = Convert.ToString((-1) * sin.mysqrt(1 - sin.Ad_Euler(Math.PI / 2 + x)[0] * sin.Ad_Euler(Math.PI / 2 + x)[0]));
                    lbl_aedel.Text = Convert.ToString((-1) * sin.mysqrt(1 - sin.Ad_Euler(Math.PI / 2 + x)[0] * sin.Ad_Euler(Math.PI / 2 + x)[0])-Math.Sin(x));
                }
            }
            lbl_aenum.Text = Convert.ToString(sin.Ad_Euler(x)[1]);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }

    class SIN
    {
        //泰勒展开
        public double[] taylor(double num)
        {
            double add;  //累加项
            double ans = 0;  //结果
            int i = 0;  //项数
            add = num;  //第一项
            do
            {
                ans = ans + add;
                i = i + 1;
                add = add * (-1) * num * num / ((2 * i) * (2 * i + 1));
            } while (myabs(add) > 0.25 * 1e-4);
            double[] res = new double[2];
            res[0] = ans;
            res[1] = i;
            return res;
        }


        //变形欧拉（二阶R-K）
        public double[] Ad_Euler(double num)
        {
            double K1, K2;
            double y, y0 = 0;
            y = y0;
            int N = 1;
            double h = num / N;
            while (h * h > 1 * 1e-4)
            {
                N = N + 1;
                h = num / N;
            }
            for (int i = 0; i < N; i++)
            {
                K1 = mysqrt(1 - y * y);
                K2 = mysqrt(1 - (y + h * K1 / 2) * (y + h * K1 / 2));
                y = y + h * K2;
            }
            double[] res = new double[2];
            res[0] = y;
            res[1] = N;
            return res;
        }

        //基本运算函数
        public double myabs(double x)
        {
            if (x >= 0)
                return x;
            else
                return -x;
        }

        public double mysqrt(double x)
        {
            double temp = 1;
            while (myabs(temp - x / temp) > 1e-6)
            {
                temp = (temp + x / temp) / 2;
            }
            return temp;
        }
    }
}
