﻿namespace NAhw2
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbx_x = new System.Windows.Forms.TextBox();
            this.btn_solve = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_tay = new System.Windows.Forms.Label();
            this.lbl_ae = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lbl_aedel = new System.Windows.Forms.Label();
            this.lbl_taydel = new System.Windows.Forms.Label();
            this.lbl_aenum = new System.Windows.Forms.Label();
            this.lbl_taynum = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 15F);
            this.label1.Location = new System.Drawing.Point(283, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(215, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "sin(x)的数值求解";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 11F);
            this.label2.Location = new System.Drawing.Point(110, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "请输入x的值：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 11F);
            this.label3.Location = new System.Drawing.Point(359, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "（弧度制）";
            // 
            // tbx_x
            // 
            this.tbx_x.Location = new System.Drawing.Point(239, 104);
            this.tbx_x.Name = "tbx_x";
            this.tbx_x.Size = new System.Drawing.Size(114, 25);
            this.tbx_x.TabIndex = 3;
            // 
            // btn_solve
            // 
            this.btn_solve.Font = new System.Drawing.Font("宋体", 11F);
            this.btn_solve.Location = new System.Drawing.Point(560, 100);
            this.btn_solve.Name = "btn_solve";
            this.btn_solve.Size = new System.Drawing.Size(75, 32);
            this.btn_solve.TabIndex = 4;
            this.btn_solve.Text = "求解";
            this.btn_solve.UseVisualStyleBackColor = true;
            this.btn_solve.Click += new System.EventHandler(this.btn_solve_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 11F);
            this.label4.Location = new System.Drawing.Point(114, 230);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 19);
            this.label4.TabIndex = 5;
            this.label4.Text = "结果";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 11F);
            this.label5.Location = new System.Drawing.Point(265, 174);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 19);
            this.label5.TabIndex = 6;
            this.label5.Text = "泰勒展开逼近";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 11F);
            this.label6.Location = new System.Drawing.Point(488, 174);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 19);
            this.label6.TabIndex = 7;
            this.label6.Text = "变形的欧拉公式";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(729, 426);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 15);
            this.label7.TabIndex = 8;
            this.label7.Text = "@qcd";
            // 
            // lbl_tay
            // 
            this.lbl_tay.AutoSize = true;
            this.lbl_tay.Font = new System.Drawing.Font("宋体", 11F);
            this.lbl_tay.Location = new System.Drawing.Point(221, 230);
            this.lbl_tay.Name = "lbl_tay";
            this.lbl_tay.Size = new System.Drawing.Size(0, 19);
            this.lbl_tay.TabIndex = 9;
            // 
            // lbl_ae
            // 
            this.lbl_ae.AutoSize = true;
            this.lbl_ae.Font = new System.Drawing.Font("宋体", 11F);
            this.lbl_ae.Location = new System.Drawing.Point(464, 230);
            this.lbl_ae.Name = "lbl_ae";
            this.lbl_ae.Size = new System.Drawing.Size(0, 19);
            this.lbl_ae.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 11F);
            this.label8.Location = new System.Drawing.Point(114, 294);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 19);
            this.label8.TabIndex = 11;
            this.label8.Text = "误差";
            // 
            // lbl_aedel
            // 
            this.lbl_aedel.AutoSize = true;
            this.lbl_aedel.Font = new System.Drawing.Font("宋体", 11F);
            this.lbl_aedel.Location = new System.Drawing.Point(464, 294);
            this.lbl_aedel.Name = "lbl_aedel";
            this.lbl_aedel.Size = new System.Drawing.Size(0, 19);
            this.lbl_aedel.TabIndex = 13;
            // 
            // lbl_taydel
            // 
            this.lbl_taydel.AutoSize = true;
            this.lbl_taydel.Font = new System.Drawing.Font("宋体", 11F);
            this.lbl_taydel.Location = new System.Drawing.Point(221, 294);
            this.lbl_taydel.Name = "lbl_taydel";
            this.lbl_taydel.Size = new System.Drawing.Size(0, 19);
            this.lbl_taydel.TabIndex = 12;
            // 
            // lbl_aenum
            // 
            this.lbl_aenum.AutoSize = true;
            this.lbl_aenum.Font = new System.Drawing.Font("宋体", 11F);
            this.lbl_aenum.Location = new System.Drawing.Point(550, 358);
            this.lbl_aenum.Name = "lbl_aenum";
            this.lbl_aenum.Size = new System.Drawing.Size(0, 19);
            this.lbl_aenum.TabIndex = 16;
            // 
            // lbl_taynum
            // 
            this.lbl_taynum.AutoSize = true;
            this.lbl_taynum.Font = new System.Drawing.Font("宋体", 11F);
            this.lbl_taynum.Location = new System.Drawing.Point(323, 358);
            this.lbl_taynum.Name = "lbl_taynum";
            this.lbl_taynum.Size = new System.Drawing.Size(0, 19);
            this.lbl_taynum.TabIndex = 15;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("宋体", 11F);
            this.label11.Location = new System.Drawing.Point(114, 358);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 19);
            this.label11.TabIndex = 14;
            this.label11.Text = "迭代次数";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(776, 450);
            this.Controls.Add(this.lbl_aenum);
            this.Controls.Add(this.lbl_taynum);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lbl_aedel);
            this.Controls.Add(this.lbl_taydel);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lbl_ae);
            this.Controls.Add(this.lbl_tay);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btn_solve);
            this.Controls.Add(this.tbx_x);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "数值大作业二";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbx_x;
        private System.Windows.Forms.Button btn_solve;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_tay;
        private System.Windows.Forms.Label lbl_ae;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbl_aedel;
        private System.Windows.Forms.Label lbl_taydel;
        private System.Windows.Forms.Label lbl_aenum;
        private System.Windows.Forms.Label lbl_taynum;
        private System.Windows.Forms.Label label11;
    }
}

