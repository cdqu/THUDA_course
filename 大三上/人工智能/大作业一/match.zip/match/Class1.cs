﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;


namespace match
{
    //移动两根火柴类
    class MoveTwo
    {
        public char this_char;
        public char[] self_one = { '!', '!', '!', '!' };
        public char[] add_one = { '!', '!', '!', '!' };
        public char[] minus_one = { '!', '!', '!', '!' };
        public char[] self_two = { '!', '!', '!', '!' };
        public char[] add_two = { '!', '!', '!', '!' };
        public char[] minus_two = { '!', '!', '!', '!' };
        public char[] self_add = { '!', '!', '!', '!' };
        public char[] self_minus = { '!', '!', '!', '!' };
    }

    //等式类
    class Equal
    {
        /*定义移动类型flag 
        public int flag_no = 0;
        public int flag_self = 1000;
        public int flag_minus = 100;
        public int flag_add = 10;*/

        //存储答案
        public List<string> Answers = new List<string>();

        DataBase db = new DataBase();

        //判断等式是否成立，成立返回0，否则返回1
        public int ifcorrect(string str)
        {
            //字符串是否为空
            if (string.IsNullOrEmpty(str))
            {
                Console.WriteLine("字符串为空");
                return 1;
            }
            //去掉空格
            str = str.Replace(" ", "");
            //获取等号位置
            int pos_eq;
            pos_eq = str.IndexOf("=");
            if (pos_eq == -1)
            {
                //Console.WriteLine("error：不存在等号" + str);
                return 1;
            }
            else if (Subchar_count(str, "=") > 1)
            {
                //Console.WriteLine("error：多个等号" + str);
                return 1;
            }
            else
            {
                //拆分等式
                string str_tail = str.Substring(pos_eq + 1);
                string str_head = str.Remove(pos_eq);
                int pos_op;
                string fir, sec;
                int fir_num, sec_num, res_num;
                int res;
                if (int.TryParse(str_tail, out res))//等号在后
                {
                    //找到运算符
                    //加号
                    if (str_head.Contains("+") && Subchar_count(str, "+") == 1
                        && (!str_head.Contains("-") && (!str_head.Contains("*")) && (!str_head.Contains("="))))
                    {
                        pos_op = str_head.IndexOf("+");
                        fir = str_head.Remove(pos_op);
                        if (fir == "")
                        {
                            return 1;
                        }
                        else
                        {
                            fir_num = Convert.ToInt16(fir);
                        }
                        sec = str_head.Substring(pos_op + 1);
                        if (sec == "")
                        {
                            return 1;
                        }
                        else
                        {
                            sec_num = Convert.ToInt16(sec);
                        }             
                        res_num = Convert.ToInt16(str_tail);
                        if ((0 <= fir_num && fir_num < 100) && (0 <= sec_num && sec_num < 100) && (0 <= res_num && res_num < 100))
                        {
                            if (fir_num + sec_num == res_num)
                            {
                                if (!Answers.Contains(str))
                                {
                                    Answers.Add(str);
                                }
                                else { };
                                return 0;
                            }
                            else
                            {
                                //Console.WriteLine("等式不成立" + str);
                                return 1;
                            }
                        }
                        else
                        {
                            //Console.WriteLine("数值超出范围");
                            return 1;
                        }
                    }
                    //减号
                    else if (str_head.Contains("-") && Subchar_count(str, "-") == 1
                        && (!str_head.Contains("+") && (!str_head.Contains("*")) && (!str_head.Contains("="))))
                    {
                        pos_op = str_head.IndexOf("-");
                        fir = str_head.Remove(pos_op);
                        if (fir == "")
                        {
                            return 1;
                        }
                        else
                        {
                            fir_num = Convert.ToInt16(fir);
                        }
                        sec = str_head.Substring(pos_op + 1);
                        if (sec == "")
                        {
                            return 1;
                        }
                        else
                        {
                            sec_num = Convert.ToInt16(sec);
                        }             
                        res_num = Convert.ToInt16(str_tail);
                        if ((0 <= fir_num && fir_num < 100) && (0 <= sec_num && sec_num < 100) && (0 <= res_num && res_num < 100))
                        {
                            if (fir_num - sec_num == res_num)
                            {
                                if (!Answers.Contains(str))
                                {
                                    Answers.Add(str);
                                }
                                else { };
                                return 0;
                            }
                            else
                            {
                                return 1;
                            }
                        }
                        else
                        {
                            //Console.WriteLine("数值超出范围");
                            return 1;
                        }
                    }
                    //乘号
                    else if (str_head.Contains("*") && Subchar_count(str, "*") == 1
                        && (!str_head.Contains("-") && (!str_head.Contains("+")) && (!str_head.Contains("="))))
                    {
                        pos_op = str_head.IndexOf("*");
                        fir = str_head.Remove(pos_op);
                        if (fir == "")
                        {
                            return 1;
                        }
                        else
                        {
                            fir_num = Convert.ToInt16(fir);
                        }
                        sec = str_head.Substring(pos_op + 1);
                        if (sec == "")
                        {
                            return 1;
                        }
                        else
                        {
                            sec_num = Convert.ToInt16(sec);
                        }             
                        res_num = Convert.ToInt16(str_tail);
                        if ((0 <= fir_num && fir_num < 100) && (0 <= sec_num && sec_num < 100) && (0 <= res_num && res_num < 100))
                        {
                            if (fir_num * sec_num == res_num)
                            {
                                if (!Answers.Contains(str))
                                {
                                    Answers.Add(str);
                                }
                                else { };
                                return 0;
                            }
                            else
                            {
                                return 1;
                            }
                        }
                        else
                        {
                            //Console.WriteLine("数值超出范围");
                            return 1;
                        }
                    }
                    //数字=数字形式
                    else if (int.TryParse(str_head, out res))
                    {
                        fir_num = Convert.ToInt32(str_head);
                        res_num = Convert.ToInt32(str_tail);
                        if ((0 <= fir_num && fir_num < 100) && (0 <= res_num && res_num < 100))
                        {
                            if (fir_num == res_num)
                            {
                                if (!Answers.Contains(str))
                                {
                                    Answers.Add(str);
                                }
                                else { };
                                return 0;
                            }
                            else
                            {
                                //Console.WriteLine("等式不成立" + str);
                                return 1;
                            }
                        }
                        else
                        {
                            //Console.WriteLine("数值超出范围");
                            return 1;
                        }
                    }
                    //其他
                    else
                    {
                        return 1;
                    }
                }
                else if (int.TryParse(str_head, out res))//等号在前
                {
                    //找到运算符
                    //加号
                    if (str_tail.Contains("+") && Subchar_count(str, "+") == 1
                        && (!str_tail.Contains("-") && (!str_tail.Contains("*")) && (!str_tail.Contains("="))))
                    {
                        pos_op = str_tail.IndexOf("+");
                        fir = str_tail.Remove(pos_op);
                        if (fir == "")
                        {
                            return 1;
                        }
                        else
                        {
                            fir_num = Convert.ToInt16(fir);
                        }
                        sec = str_tail.Substring(pos_op + 1);
                        if (sec == "")
                        {
                            return 1;
                        }
                        else
                        {
                            sec_num = Convert.ToInt16(sec);
                        }
                        res_num = Convert.ToInt16(str_head);
                        if ((0 <= fir_num && fir_num < 100) && (0 <= sec_num && sec_num < 100) && (0 <= res_num && res_num < 100))
                        {
                            if (fir_num + sec_num == res_num)
                            {
                                if (!Answers.Contains(str))
                                {
                                    Answers.Add(str);
                                }
                                else { };
                                return 0;
                            }
                            else
                            {
                                return 1;
                            }
                        }
                        else
                        {
                            //Console.WriteLine("数值超出范围");
                            return 1;
                        }
                    }
                    //减号
                    else if (str_tail.Contains("-") && Subchar_count(str, "-") == 1
                        && (!str_tail.Contains("+") && (!str_tail.Contains("*")) && (!str_tail.Contains("="))))
                    {
                        pos_op = str_tail.IndexOf("-");
                        fir = str_tail.Remove(pos_op);
                        if (fir == "")
                        {
                            return 1;
                        }
                        else
                        {
                            fir_num = Convert.ToInt16(fir);
                        }
                        sec = str_tail.Substring(pos_op + 1);
                        if (sec == "")
                        {
                            return 1;
                        }
                        else
                        {
                            sec_num = Convert.ToInt16(sec);
                        }
                        res_num = Convert.ToInt16(str_head);
                        if ((0 <= fir_num && fir_num < 100) && (0 <= sec_num && sec_num < 100) && (0 <= res_num && res_num < 100))
                        {
                            if (fir_num - sec_num == res_num)
                            {
                                if (!Answers.Contains(str))
                                {
                                    Answers.Add(str);
                                }
                                else { };
                                return 0;
                            }
                            else
                            {
                                return 1;
                            }
                        }
                        else
                        {
                            //Console.WriteLine("数值超出范围");
                            return 1;
                        }
                    }
                    //乘号
                    else if (str_tail.Contains("*") && Subchar_count(str, "*") == 1
                        && (!str_tail.Contains("-") && (!str_tail.Contains("+")) && (!str_tail.Contains("="))))
                    {
                        pos_op = str_tail.IndexOf("*");
                        fir = str_tail.Remove(pos_op);
                        if (fir == "")
                        {
                            return 1;
                        }
                        else
                        {
                            fir_num = Convert.ToInt16(fir);
                        }
                        sec = str_tail.Substring(pos_op + 1);
                        if (sec == "")
                        {
                            return 1;
                        }
                        else
                        {
                            sec_num = Convert.ToInt16(sec);
                        }
                        res_num = Convert.ToInt16(str_head);
                        if ((0 <= fir_num && fir_num < 100) && (0 <= sec_num && sec_num < 100) && (0 <= res_num && res_num < 100))
                        {
                            if (fir_num * sec_num == res_num)
                            {
                                if (!Answers.Contains(str))
                                {
                                    Answers.Add(str);
                                }
                                else { };
                                return 0;
                            }
                            else
                            {
                                return 1;
                            }
                        }
                        else
                        {
                            //Console.WriteLine("数值超出范围");
                            return 1;
                        }
                    }
                    //其他
                    else
                    {
                        return 1;
                    }
                }
                else
                {
                    return 1;
                }
            }
        }

        //拆分等式
        char[] cstring = new char[10];
        public void split(string str)
        {
            int charshu = str.Length;//等式中包含的字符个数

            string s1;
            for (int i = 0; i < charshu; i++)
            {
                s1 = str.Substring(i, 1);
                cstring[i] = Convert.ToChar(s1);
            }
        }

        //求一个字符串中指定字符的个数
        public int Subchar_count(string str, string substring)
        {
            if (str.Contains(substring))
            {
                string restr = str.Replace(substring, "");
                return (str.Length - restr.Length) / substring.Length;
            }
            return 0;
        }

        //更换指定位置的字符
        string change_char(string str, int pos, char rechar)
        {
            char[] cs = str.ToCharArray();
            cs[pos] = rechar;
            return new string(cs);
        }

        ///////
        /////////////////////////////////////////移动一根///////////////////////////////////////////////////////
        ///////       
        //创建查找表格
        //0~=每个字符能变成的字符个数
        int[] change_n = { 4, 3, 2, 4, 1, 4, 5, 2, 4, 6, 4, 4, 1, 3 };

        //结构体
        struct match_change
        {
            internal int flag;  //移动操作权值
            internal char data;  //变成的新字符
        };
        //创建结构体数组
        match_change[][] mcg = new match_change[15][];
        //数据初始化
        public void getdata_one()
        {
            for (int n = 0; n < 15; n++)
            {
                mcg[n] = new match_change[8];
            }
            //0
            mcg[0][0].flag = 0; mcg[0][0].data = '0';
            mcg[0][1].flag = 10; mcg[0][1].data = '8';
            mcg[0][2].flag = 1000; mcg[0][2].data = '6';
            mcg[0][3].flag = 1000; mcg[0][3].data = '9';
            //1
            mcg[1][0].flag = 0; mcg[1][0].data = '1';
            mcg[1][1].flag = 10; mcg[1][1].data = '7';
            mcg[1][2].flag = 1000; mcg[1][2].data = '+';
            //2
            mcg[2][0].flag = 0; mcg[2][0].data = '2';
            mcg[2][1].flag = 1000; mcg[2][1].data = '3';
            //3
            mcg[3][0].flag = 0; mcg[3][0].data = '3';
            mcg[3][1].flag = 10; mcg[3][1].data = '9';
            mcg[3][2].flag = 1000; mcg[3][2].data = '2';
            mcg[3][3].flag = 1000; mcg[3][3].data = '5';
            //4
            mcg[4][0].flag = 0; mcg[4][0].data = '4';
            //5
            mcg[5][0].flag = 0; mcg[5][0].data = '5';
            mcg[5][1].flag = 10; mcg[5][1].data = '6';
            mcg[5][2].flag = 10; mcg[5][2].data = '9';
            mcg[5][3].flag = 1000; mcg[5][3].data = '3';
            //6
            mcg[6][0].flag = 0; mcg[6][0].data = '6';
            mcg[6][1].flag = 10; mcg[6][1].data = '8';
            mcg[6][2].flag = 100; mcg[6][2].data = '5';
            mcg[6][3].flag = 1000; mcg[6][3].data = '9';
            mcg[6][4].flag = 1000; mcg[6][4].data = '0';
            //7
            mcg[7][0].flag = 0; mcg[7][0].data = '7';
            mcg[7][1].flag = 100; mcg[7][1].data = '1';
            //8
            mcg[8][0].flag = 0; mcg[8][0].data = '8';
            mcg[8][1].flag = 100; mcg[8][1].data = '9';
            mcg[8][2].flag = 100; mcg[8][2].data = '6';
            mcg[8][3].flag = 100; mcg[8][3].data = '0';
            //9
            mcg[9][0].flag = 0; mcg[9][0].data = '9';
            mcg[9][1].flag = 10; mcg[9][1].data = '8';
            mcg[9][2].flag = 100; mcg[9][2].data = '5';
            mcg[9][3].flag = 100; mcg[9][3].data = '3';
            mcg[9][4].flag = 1000; mcg[9][4].data = '6';
            mcg[9][5].flag = 1000; mcg[9][5].data = '0';
            //+
            mcg[10][0].flag = 0; mcg[10][0].data = '+';
            mcg[10][1].flag = 100; mcg[10][1].data = '-';
            mcg[10][2].flag = 1000; mcg[10][2].data = '1';
            mcg[10][3].flag = 1000; mcg[10][3].data = '=';
            //-
            mcg[11][0].flag = 0; mcg[11][0].data = '-';
            mcg[11][1].flag = 10; mcg[11][1].data = '+';
            mcg[11][2].flag = 10; mcg[11][2].data = '=';
            mcg[11][3].flag = 100; mcg[11][3].data = ' ';
            //*
            mcg[12][0].flag = 0; mcg[12][0].data = '*';
            //=
            mcg[13][0].flag = 0; mcg[13][0].data = '=';
            mcg[13][1].flag = 100; mcg[13][1].data = '-';
            mcg[13][2].flag = 1000; mcg[13][2].data = '+';
        }

        //记录原始等式
        public string ss;

        //移动权值
        int flag = 0;
        //记录变过的字符
        char[] snew = new char[10];
        public string str_route;
        //标记是否走过
        int[] string_flag = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

        //递归搜索
        public bool solvedfs(int pos)
        {
            //判定【1】总移动权值是否符合要求【2】等式是否成立
            if (pos == ss.Length)
            {
                if ((flag == 1000 || flag == 110) && ifcorrect(str_route) == 0)
                {
                    return true;
                }
                return false;
            }
            //获取该位置字符信息
            char c = cstring[pos];
            int cn = -1;
            if (c >= '0' && c <= '9') { cn = c - 48; }
            else if (c == '+') { cn = 10; }
            else if (c == '-') { cn = 11; }
            else if (c == '*') { cn = 12; }
            else if (c == '=') { cn = 13; }
            else { Console.WriteLine("error"); return false; }
            //路口数
            int direc = change_n[cn];
            //标记走过
            string_flag[pos] = 1;

            for (int i = 0; i < direc; i++)
            {
                str_route = change_char(str_route, pos, mcg[cn][i].data);  //替换字符
                flag = flag + mcg[cn][i].flag;  //更新总移动权值
                //递归
                if (solvedfs(pos + 1)) { }
                flag = flag - mcg[cn][i].flag;
            }
            //恢复标记
            string_flag[pos] = 0;
            return false;
        }



        //for循环搜索
        int[] cton = new int[10];
        int[] direc = new int[10];
        string s_new;

        public void solve_for()
        {
            //获取字符信息
            for (int i = 0; i < ss.Length; i++)
            {
                char c = cstring[i];
                int cn = -1;
                if (c >= '0' && c <= '9') { cn = c - 48; }
                else if (c == '+') { cn = 10; }
                else if (c == '-') { cn = 11; }
                else if (c == '*') { cn = 12; }
                else if (c == '=') { cn = 13; }
                else { Console.WriteLine("error"); }
                //数字化
                cton[i] = cn;
                //路口数
                direc[i] = change_n[cn];
            }

            //只改变自身
            for (int i = 0; i < ss.Length; i++)
            {
                for (int q = 0; q < direc[i]; q++)
                {
                    if (mcg[cton[i]][q].flag == 1000)  //移动操作权值=1000：仅在自身移动
                    {
                        s_new = change_char(ss, i, mcg[cton[i]][q].data);  //替换，生成新等式
                        ifcorrect(s_new);  //判定正确性
                    }
                }
            }

            //一加一减
            for (int i = 0; i < ss.Length; i++)
            {
                //先加后减
                for (int q = 0; q < direc[i]; q++)
                {
                    if (mcg[cton[i]][q].flag == 10)  //移动操作权值=10：加一根
                    {
                        s_new = change_char(ss, i, mcg[cton[i]][q].data);
                        for (int j = i + 1; j < ss.Length; j++)
                        {
                            for (int p = 0; p < direc[j]; p++)
                            {
                                if (mcg[cton[j]][p].flag == 100)  //移动操作权值=100：减一根
                                {
                                    s_new = change_char(s_new, j, mcg[cton[j]][p].data);
                                    ifcorrect(s_new);  //判断
                                    s_new = change_char(s_new, j, cstring[j]);
                                }
                            }
                        }
                        s_new = change_char(ss, i, cstring[i]);
                    }
                }
                //先减后加
                for (int q = 0; q < direc[i]; q++)
                {
                    if (mcg[cton[i]][q].flag == 100)  //减一根
                    {
                        s_new = change_char(ss, i, mcg[cton[i]][q].data);
                        for (int j = i + 1; j < ss.Length; j++)
                        {
                            for (int p = 0; p < direc[j]; p++)
                            {
                                if (mcg[cton[j]][p].flag == 10)  //加一根
                                {
                                    s_new = change_char(s_new, j, mcg[cton[j]][p].data);
                                    ifcorrect(s_new);  //判断
                                    s_new = change_char(s_new, j, cstring[j]);

                                }
                            }
                        }
                        s_new = change_char(ss, i, cstring[i]);
                    }
                }

            }
        }


        /// <summary>
        /// /////////////////////////////// 移动两根 //////////////////////////////////////////
        /// </summary>
        //创建数组
        MoveTwo[] ct = new MoveTwo[15];

        //数据初始化
        public void getdata_two()
        {
            for (int i = 0; i < 15; i++)
            {
                ct[i] = new MoveTwo();
            }
            //0
            ct[0].this_char = '0';
            ct[0].self_one[0] = '6'; ct[0].self_one[1] = '9';
            ct[0].add_one[0] = '8';
            ct[0].self_two[0] = '6'; ct[0].self_two[1] = '9';
            ct[0].self_add[0] = '8';
            ct[0].self_minus[0] = '3'; ct[0].self_minus[1] = '5'; ct[0].self_minus[2] = '2';

            //1
            ct[1].this_char = '1';
            ct[1].self_one[0] = '+';
            ct[1].add_one[0] = '7';
            ct[1].add_two[0] = '4';
            ct[1].self_two[0] = '='; ct[1].self_two[1] = '*';
            ct[1].minus_two[0] = ' ';
            ct[1].self_add[0] = '7';
            ct[1].self_minus[0] = '-';

            //2
            ct[2].this_char = '2';
            ct[2].self_one[0] = '3';
            ct[2].self_two[0] = '3'; ct[2].self_two[1] = '5';
            ct[2].add_two[0] = '8';
            ct[2].self_add[0] = '6'; ct[2].self_add[1] = '9'; ct[2].self_add[2] = '0';

            //3
            ct[3].this_char = '3';
            ct[3].self_one[0] = '2'; ct[3].self_one[1] = '5';
            ct[3].add_one[0] = '9';
            ct[3].self_two[0] = '2'; ct[3].self_two[1] = '5';
            ct[3].add_two[0] = '8';
            ct[3].minus_two[0] = '7';
            ct[3].self_add[0] = '0'; ct[3].self_add[1] = '6'; ct[3].self_add[2] = '9';
            ct[3].self_minus[0] = '4';

            //4
            ct[4].this_char = '4';
            ct[4].add_two[0] = '9';
            ct[4].minus_two[0] = '1';
            ct[4].self_add[0] = '3';
            ct[4].self_minus[0] = '7';

            //5
            ct[5].this_char = '5';
            ct[5].self_one[0] = '3';
            ct[5].add_one[0] = '6'; ct[5].add_one[1] = '9';
            ct[5].self_two[0] = '2'; ct[5].self_two[1] = '3';
            ct[5].add_two[0] = '8';
            ct[5].self_add[0] = '0'; ct[5].self_add[1] = '6'; ct[5].self_add[2] = '9';
            ct[5].self_minus[0] = '4';

            //6
            ct[6].this_char = '6';
            ct[6].self_one[0] = '0'; ct[6].self_one[1] = '9';
            ct[6].add_one[0] = '8';
            ct[6].minus_one[0] = '5';
            ct[6].self_two[0] = '0'; ct[6].self_two[1] = '9';
            ct[6].self_add[0] = '8';
            ct[6].self_minus[0] = '2'; ct[6].self_minus[1] = '3'; ct[6].self_minus[2] = '5';

            //7
            ct[7].this_char = '7';
            ct[7].minus_one[0] = '1';
            ct[7].add_two[0] = '3';
            ct[7].minus_two[0] = '-';
            ct[7].self_add[0] = '4';
            ct[7].self_minus[0] = '1'; ct[7].self_minus[1] = '+'; ct[7].self_minus[2] = '=';

            //8
            ct[8].this_char = '8';
            ct[8].minus_one[0] = '0'; ct[8].minus_one[1] = '6'; ct[8].minus_one[2] = '9';
            ct[8].minus_two[0] = '3'; ct[8].minus_two[1] = '5';
            ct[8].self_minus[0] = '0'; ct[8].self_minus[1] = '6'; ct[8].self_minus[2] = '9';

            //9
            ct[9].this_char = '9';
            ct[9].self_one[0] = '0'; ct[9].self_one[1] = '6';
            ct[9].add_one[0] = '8';
            ct[9].minus_one[0] = '3'; ct[9].minus_one[1] = '5';
            ct[9].self_two[0] = '0'; ct[9].self_two[1] = '6';
            ct[9].minus_two[0] = '4';
            ct[9].self_add[0] = '8';
            ct[9].self_minus[0] = '2'; ct[9].self_minus[1] = '3'; ct[9].self_minus[2] = '5';

            //+
            ct[10].this_char = '+';
            ct[10].self_one[0] = '1'; ct[10].self_one[1] = '=';
            ct[10].minus_one[0] = '-';
            ct[10].self_two[0] = '*';
            ct[10].minus_two[0] = ' ';
            ct[10].self_add[0] = '7';
            ct[10].self_minus[0] = '-';

            //-
            ct[11].this_char = '-';
            ct[11].add_one[0] = '+'; ct[11].add_one[1] = '=';
            ct[11].minus_one[0] = ' ';
            ct[11].add_two[0] = '7';
            ct[11].self_add[0] = '1'; ct[11].self_add[1] = '*';

            //*
            ct[12].this_char = '*';
            ct[12].self_two[0] = '+'; ct[12].self_two[1] = '1'; ct[12].self_two[2] = '=';
            ct[12].minus_two[0] = ' ';
            ct[12].self_minus[0] = '-';

            //=
            ct[13].this_char = '=';
            ct[13].self_one[0] = '+';
            ct[13].minus_one[0] = '-';
            ct[13].self_two[0] = '*'; ct[13].self_two[1] = '1';
            ct[13].minus_two[0] = ' ';
            ct[13].self_add[0] = '7';
        }

        //转数字形式
        int[] cn_arr = new int[10];

        //for循环
        public void solvefor_two()
        {
            //获取字符信息
            for (int i = 0; i < ss.Length; i++)
            {
                char c = cstring[i];
                int cn = -1;
                if (c >= '0' && c <= '9') { cn = c - 48; }
                else if (c == '+') { cn = 10; }
                else if (c == '-') { cn = 11; }
                else if (c == '*') { cn = 12; }
                else if (c == '=') { cn = 13; }
                else { Console.WriteLine("error"); }
                cn_arr[i] = cn;
            }

            /////////////////////两根均不换字符/////////////////////
            //一个字符上移两根
            for (int i = 0; i < ss.Length; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (ct[cn_arr[i]].self_two[j] != '!')
                    {
                        s_new = change_char(ss, i, ct[cn_arr[i]].self_two[j]);
                        ifcorrect(s_new);
                    }
                }
            }
            //两个字符各移一根
            for (int i = 0; i < ss.Length; i++)
            {
                for (int p = 0; p < 4; p++)
                {
                    if (ct[cn_arr[i]].self_one[p] != '!')
                    {
                        s_new = change_char(ss, i, ct[cn_arr[i]].self_one[p]);
                        for (int j = i + 1; j < ss.Length; j++)
                        {
                            for (int q = 0; q < 4; q++)
                            {
                                if (ct[cn_arr[j]].self_one[q] != '!')
                                {
                                    s_new = change_char(s_new, j, ct[cn_arr[j]].self_one[q]);

                                    ifcorrect(s_new);
                                    s_new = change_char(ss, i, ct[cn_arr[i]].self_one[p]);
                                }
                            }
                        }
                        s_new = change_char(ss, i, cstring[i]);
                    }
                }
            }
            /////////////////一根在字符间移动，一根不换位置//////////////
            //一个self_one，另外两个加减一根
            for (int i = 0; i < ss.Length; i++)
            {
                for (int p = 0; p < 4; p++)
                {
                    if (ct[cn_arr[i]].self_one[p] != '!')
                    {
                        s_new = change_char(ss, i, ct[cn_arr[i]].self_one[p]);
                        for (int j = 0; j < ss.Length; j++)
                        {
                            if (j != i)
                            {
                                for (int q = 0; q < 4; q++)
                                {
                                    if (ct[cn_arr[j]].add_one[q] != '!')
                                    {
                                        s_new = change_char(s_new, j, ct[cn_arr[j]].add_one[q]);
                                        for (int k = 0; k < ss.Length; k++)
                                        {
                                            if (k != i && k != j)
                                            {
                                                for (int s = 0; s < 4; s++)
                                                {
                                                    if (ct[cn_arr[k]].minus_one[s] != '!')
                                                    {
                                                        s_new = change_char(s_new, k, ct[cn_arr[k]].minus_one[s]);
                                                        ifcorrect(s_new);
                                                        s_new = change_char(s_new, k, cstring[k]);
                                                    }
                                                }
                                            }
                                        }
                                        s_new = change_char(ss, i, ct[cn_arr[i]].self_one[p]);
                                    }
                                }
                            }
                        }
                        s_new = change_char(ss, i, cstring[i]);
                    }
                }
            }
            //一个self_add/self_minus，另一个minus_one/add_one
            for (int i = 0; i < ss.Length; i++)
            {
                for (int p = 0; p < 4; p++)
                {
                    if (ct[cn_arr[i]].self_add[p] != '!')
                    {
                        s_new = change_char(ss, i, ct[cn_arr[i]].self_add[p]);
                        for (int j = 0; j < ss.Length; j++)
                        {
                            if (j != i)
                            {
                                for (int q = 0; q < 4; q++)
                                {
                                    if (ct[cn_arr[j]].minus_one[q] != '!')
                                    {
                                        s_new = change_char(s_new, j, ct[cn_arr[j]].minus_one[q]);
                                        ifcorrect(s_new);
                                        s_new = change_char(ss, i, ct[cn_arr[i]].self_add[p]);
                                    }
                                }
                            }
                        }
                        s_new = change_char(ss, i, cstring[i]);
                    }
                }
            }

            for (int i = 0; i < ss.Length; i++)
            {
                for (int p = 0; p < 4; p++)
                {
                    if (ct[cn_arr[i]].self_minus[p] != '!')
                    {
                        s_new = change_char(ss, i, ct[cn_arr[i]].self_minus[p]);
                        for (int j = 0; j < ss.Length; j++)
                        {
                            if (j != i)
                            {
                                for (int q = 0; q < 4; q++)
                                {
                                    if (ct[cn_arr[j]].add_one[q] != '!')
                                    {
                                        s_new = change_char(s_new, j, ct[cn_arr[j]].add_one[q]);
                                        ifcorrect(s_new);
                                        s_new = change_char(ss, i, ct[cn_arr[i]].self_minus[p]);
                                    }
                                }
                            }
                        }
                        s_new = change_char(ss, i, cstring[i]);
                    }
                }
            }
            ///////////////////两根均换字符位置////////////////////
            //+2，-2
            for (int i = 0; i < ss.Length; i++)
            {
                for (int p = 0; p < 4; p++)
                {
                    if (ct[cn_arr[i]].add_two[p] != '!')
                    {
                        s_new = change_char(ss, i, ct[cn_arr[i]].add_two[p]);
                        for (int j = i + 1; j < ss.Length; j++)
                        {
                            for (int q = 0; q < 4; q++)
                            {
                                if (ct[cn_arr[j]].minus_two[q] != '!')
                                {
                                    s_new = change_char(s_new, j, ct[cn_arr[j]].minus_two[q]);

                                    ifcorrect(s_new);
                                    s_new = change_char(ss, i, ct[cn_arr[i]].add_two[p]);
                                }
                            }
                        }
                        s_new = change_char(ss, i, cstring[i]);
                    }
                }
            }
            //+2，-1，-1
            for (int i = 0; i < ss.Length; i++)
            {
                for (int p = 0; p < 4; p++)
                {
                    if (ct[cn_arr[i]].add_two[p] != '!')
                    {
                        s_new = change_char(ss, i, ct[cn_arr[i]].add_two[p]);
                        for (int j = 0; j < ss.Length; j++)
                        {
                            if (j != i)
                            {
                                for (int q = 0; q < 4; q++)
                                {
                                    if (ct[cn_arr[j]].minus_one[q] != '!')
                                    {
                                        s_new = change_char(s_new, j, ct[cn_arr[j]].minus_one[q]);
                                        for (int k = 0; k < ss.Length; k++)
                                        {
                                            if (k != i && k != j)
                                            {
                                                for (int s = 0; s < 4; s++)
                                                {
                                                    if (ct[cn_arr[k]].minus_one[s] != '!')
                                                    {
                                                        s_new = change_char(s_new, k, ct[cn_arr[k]].minus_one[s]);
                                                        ifcorrect(s_new);
                                                        s_new = change_char(s_new, k, cstring[k]);
                                                    }
                                                }
                                            }
                                        }
                                        s_new = change_char(ss, i, ct[cn_arr[i]].add_two[p]);
                                    }
                                }
                            }
                        }
                        s_new = change_char(ss, i, cstring[i]);
                    }
                }
            }
            //-2，+1，+1
            for (int i = 0; i < ss.Length; i++)
            {
                for (int p = 0; p < 4; p++)
                {
                    if (ct[cn_arr[i]].minus_two[p] != '!')
                    {
                        s_new = change_char(ss, i, ct[cn_arr[i]].minus_two[p]);
                        for (int j = 0; j < ss.Length; j++)
                        {
                            if (j != i)
                            {
                                for (int q = 0; q < 4; q++)
                                {
                                    if (ct[cn_arr[j]].add_one[q] != '!')
                                    {
                                        s_new = change_char(s_new, j, ct[cn_arr[j]].add_one[q]);
                                        for (int k = 0; k < ss.Length; k++)
                                        {
                                            if (k != i && k != j)
                                            {
                                                for (int s = 0; s < 4; s++)
                                                {
                                                    if (ct[cn_arr[k]].add_one[s] != '!')
                                                    {
                                                        s_new = change_char(s_new, k, ct[cn_arr[k]].add_one[s]);
                                                        ifcorrect(s_new);
                                                        s_new = change_char(s_new, k, cstring[k]);
                                                    }
                                                }
                                            }
                                        }
                                        s_new = change_char(ss, i, ct[cn_arr[i]].minus_two[p]);
                                    }
                                }
                            }
                        }
                        s_new = change_char(ss, i, cstring[i]);
                    }
                }
            }
            //+1，+1，-1，-1
            for (int i = 0; i < ss.Length; i++)
            {
                for (int p = 0; p < 4; p++)
                {
                    if (ct[cn_arr[i]].add_one[p] != '!')
                    {
                        s_new = change_char(ss, i, ct[cn_arr[i]].add_one[p]);
                        for (int j = 0; j < ss.Length; j++)
                        {
                            if (j != i)
                            {
                                for (int q = 0; q < 4; q++)
                                {
                                    if (ct[cn_arr[j]].add_one[q] != '!')
                                    {
                                        s_new = change_char(s_new, j, ct[cn_arr[j]].add_one[q]);
                                        for (int k = 0; k < ss.Length; k++)
                                        {
                                            if (k != i && k != j)
                                            {
                                                for (int s = 0; s < 4; s++)
                                                {
                                                    if (ct[cn_arr[k]].minus_one[s] != '!')
                                                    {
                                                        s_new = change_char(s_new, k, ct[cn_arr[k]].minus_one[s]);
                                                        for (int t = 0; t < ss.Length; t++)
                                                        {
                                                            if (t != i && t != j && t != k)
                                                            {
                                                                for (int r = 0; r < 4; r++)
                                                                {
                                                                    if (ct[cn_arr[t]].minus_one[r] != '!')
                                                                    {
                                                                        s_new = change_char(s_new, t, ct[cn_arr[t]].minus_one[r]);
                                                                        ifcorrect(s_new);
                                                                        s_new = change_char(s_new, t, cstring[t]);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        s_new = change_char(s_new, k, cstring[k]);
                                                    }
                                                }
                                            }
                                        }
                                        s_new = change_char(ss, i, ct[cn_arr[i]].add_one[p]);
                                    }
                                }
                            }
                        }
                        s_new = change_char(ss, i, cstring[i]);
                    }
                }
            }

        }

    }

    //数据库类
    class DataBase
    {
        //检查数据库是否存在
        public void CheckDB(string dbPath)
        {
            try
            {
                //判断数据文件是否存在
                bool dbExist = System.IO.File.Exists(dbPath);
                if (!dbExist)
                {
                    SQLiteConnection.CreateFile(dbPath);      //不存在，新建数据库           
                }
            }
            catch (Exception) { }
        }

        //删除数据库
        public void DeleteDB(string dbPath)
        {
            if (System.IO.File.Exists(dbPath))
            {
                System.IO.File.Delete(dbPath);
            }
        }

        //创建表（存储答案）
        public void Create_An_Table(string dbPath)
        {
            SQLiteConnection cn = new SQLiteConnection("data source=" + dbPath);
            if (cn.State != System.Data.ConnectionState.Open)
            {
                cn.Open();
                SQLiteCommand cmd = new SQLiteCommand();
                cmd.Connection = cn;
                cmd.CommandText = "CREATE TABLE Answers(Answer string)";
                cmd.ExecuteNonQuery();
            }
            cn.Close();
        }

        //删除表
        public void DeleteTable(string dbPath, string tableName)
        {
            SQLiteConnection cn = new SQLiteConnection("data source=" + dbPath);
            if (cn.State != System.Data.ConnectionState.Open)
            {
                cn.Open();
                SQLiteCommand cmd = new SQLiteCommand();
                cmd.Connection = cn;
                cmd.CommandText = "DROP TABLE IF EXISTS " + tableName;
                cmd.ExecuteNonQuery();
            }
            cn.Close();
        }

        //向表中插入数据
        public void Insert(string dbPath, string ans)
        {
            SQLiteConnection cn = new SQLiteConnection("data source=" + dbPath);
            cn.Open();
            SQLiteCommand cmd = new SQLiteCommand();
            cmd.Connection = cn;
            cmd.CommandText = "INSERT INTO Answers VALUES('" + ans + "')";
            cmd.ExecuteNonQuery();
            cn.Close();
        }

        //从表中读取数据（除去重复数据）
        public void ShowData(string dbPath, string tableName, string data)
        {
            Form1 f1 = new Form1();

            SQLiteConnection cn = new SQLiteConnection("data source=" + dbPath);
            cn.Open();
            SQLiteCommand cmd = new SQLiteCommand();
            cmd.Connection = cn;
            cmd.CommandText = "SELECT DISTINCT " + data + " FROM " + tableName;
            SQLiteDataReader sr = cmd.ExecuteReader();
            while (sr.Read())
            {
                Console.WriteLine(sr.GetString(0));
                f1.ans_text.Text = sr.GetString(0).ToString();
            }
            sr.Close();
            cn.Close();
        }
    }
}
