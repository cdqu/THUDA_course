﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;
using System.Diagnostics;


namespace match
{
    public partial class Form1 : Form
    {
        //存储题目，按难度分
        //low
        List<string> Que_low = new List<string>();
        int qn_low=0;
        //mid
        List<string> Que_mid = new List<string>();
        int qn_mid=0;
        //high
        List<string> Que_high = new List<string>();
        int qn_high=0;

        //模式flag，题库1，自主2，随机3
        int mode=0;

        //计时
        Stopwatch sw1 = new Stopwatch();
        Stopwatch sw2 = new Stopwatch();

        //初始化
        Equal eq=new Equal();
        DataBase db = new DataBase();

        public Form1()
        {
            InitializeComponent();            
        }

        //初始化
        private void Form1_Load(object sender, EventArgs e)
        {
            //皮肤
            skinEngine1.SkinFile = Application.StartupPath + "//DeepCyan.ssk";
            //默认设置
            this.que_text.Enabled = false;
            this.que_text.Text = "默认题库出题模式";
            mode = 1;
            this.btn_yes.Enabled = false;
            this.modetxt.Text = "当前为题库出题";
            this.level.SelectedIndex = level.Items.IndexOf("低");
            this.move_num.SelectedIndex = move_num.Items.IndexOf("一根");
            this.nextAns.Enabled = false;
            this.radioButton_dfs.Checked = true;

            //连接数据库            
            db.CheckDB("match_db.db");
            //从库中调出题目存入list
            SQLiteConnection cn = new SQLiteConnection("data source=" + "match_db.db");
            cn.Open();
            SQLiteCommand cmd = new SQLiteCommand();
            cmd.Connection = cn;
            //low
            cmd.CommandText = "SELECT Equals FROM Ques WHERE Level = 'low'";
            SQLiteDataReader sr = cmd.ExecuteReader();
            while (sr.Read())
            {
                Que_low.Add(sr.GetString(0));
            }
            sr.Close();
            //mid
            cmd.CommandText = "SELECT Equals FROM Ques WHERE Level = 'mid'";
            sr = cmd.ExecuteReader();
            while (sr.Read())
            {
                Que_mid.Add(sr.GetString(0));
            }
            sr.Close();
            //high         
            cmd.CommandText = "SELECT Equals FROM Ques WHERE Level = 'high'";
            sr = cmd.ExecuteReader();
            while (sr.Read())
            {
                Que_high.Add(sr.GetString(0));
            }

            //展示第一题
            eq.ss=Que_low[0];
            show_que_pic(eq.ss);
        }

        //展示火柴图片
        //题目
        public void show_que_pic(string str)
        {
            int i=0;   
            string[] sarr=new string[10];
            
            for(int j=0;j<str.Length;j++)
            {
                sarr[j]=str.Substring(j,1);
            }
            //转乘号
            for (int m = 0; m < str.Length; m++)
            {
                if (sarr[m] == "*")
                {
                    sarr[m] = "@";
                }
                else { }
            }
            if (i < str.Length)
            {
                this.PB1.Load(sarr[i] + ".png");
            }
            else { this.PB1.Image = null; }
            i = i + 1;
            if (i < str.Length)
            {
                this.PB2.Load(sarr[i] + ".png");
            }
            else { this.PB2.Image = null; }
            i = i + 1;
            if (i < str.Length)
            {
                this.PB3.Load(sarr[i] + ".png");
            }
            else { this.PB3.Image = null; }
            i = i + 1;
            if (i < str.Length)
            {
                this.PB4.Load(sarr[i] + ".png");
            }
            else { this.PB4.Image = null; }
            i = i + 1;
            if (i < str.Length)
            {
                this.PB5.Load(sarr[i] + ".png");
            }
            else { this.PB5.Image = null; }
            i = i + 1;
            if (i < str.Length)
            {
                this.PB6.Load(sarr[i] + ".png");
            }
            else { this.PB6.Image = null; }
            i = i + 1;
            if (i < str.Length)
            {
                this.PB7.Load(sarr[i] + ".png");
            }
            else { this.PB7.Image = null; }
            i = i + 1;
            if (i < str.Length)
            {
                this.PB8.Load(sarr[i] + ".png");
            }
            else { this.PB8.Image = null; }
        }

        //答案
        public void show_ans_pic(string str)
        {
            int i = 0;
            string[] sarr = new string[10];
            for (int j = 0; j < str.Length; j++)
            {
                sarr[j] = str.Substring(j, 1);
            }
            //转乘号
            for (int m = 0; m < str.Length; m++)
            {
                if (sarr[m] == "*")
                {
                    sarr[m] = "@";
                }
                else { }
            }
            if (i < str.Length)
            {
                this.pictureBox9.Load(sarr[i] + ".png");
            }
            else { this.pictureBox9.Image = null; }
            i = i + 1;
            if (i < str.Length)
            {
                this.pictureBox10.Load(sarr[i] + ".png");
            }
            else { this.pictureBox10.Image = null; }
            i = i + 1;
            if (i < str.Length)
            {
                this.pictureBox11.Load(sarr[i] + ".png");
            }
            else { this.pictureBox11.Image = null; }
            i = i + 1;
            if (i < str.Length)
            {
                this.pictureBox12.Load(sarr[i] + ".png");
            }
            else { this.pictureBox12.Image = null; }
            i = i + 1;
            if (i < str.Length)
            {
                this.pictureBox13.Load(sarr[i] + ".png");
            }
            else { this.pictureBox13.Image = null; }
            i = i + 1;
            if (i < str.Length)
            {
                this.pictureBox14.Load(sarr[i] + ".png");
            }
            else { this.pictureBox14.Image = null; }
            i = i + 1;
            if (i < str.Length)
            {
                this.pictureBox15.Load(sarr[i] + ".png");
            }
            else { this.pictureBox15.Image = null; }
            i = i + 1;
            if (i < str.Length)
            {
                this.pictureBox16.Load(sarr[i] + ".png");
            }
            else { this.pictureBox16.Image = null; }
        }

        //清空图片
        public void clear_que()
        {
            this.PB1.Image = null;
            this.PB2.Image = null;
            this.PB3.Image = null;
            this.PB4.Image = null;
            this.PB5.Image = null;
            this.PB6.Image = null;
            this.PB7.Image = null;
            this.PB8.Image = null;
        }
        public void clear_ans()
        {
            this.pictureBox9.Image = null;
            this.pictureBox10.Image = null;
            this.pictureBox11.Image = null;
            this.pictureBox12.Image = null;
            this.pictureBox13.Image = null;
            this.pictureBox14.Image = null;
            this.pictureBox15.Image = null;
            this.pictureBox16.Image = null;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        //求解
        private void btnSave_Click(object sender, EventArgs e)
        {
            sw1.Reset();
            eq.str_route = eq.ss;

            if (eq.ifcorrect(eq.ss) == 0)
            {
                ans_text.Text = eq.ss;
                MessageBox.Show("原等式成立！");
            }
            else { }

            if (move_num.SelectedItem.ToString() == "一根")
            {
                eq.getdata_one();
                eq.split(eq.ss);
                if (radioButton_dfs.Checked == true)
                {
                    sw1.Start();
                    eq.solvedfs(0);
                    sw1.Stop();
                }
                else
                {
                    sw1.Start();
                    eq.solve_for();
                    sw1.Stop();
                }
            }
            else if (move_num.SelectedItem.ToString() == "两根")
            {
                eq.getdata_two();
                eq.split(eq.ss);
                sw1.Start();
                eq.solvefor_two();
                sw1.Stop();
            }
            else { }

            if (eq.Answers.Count == 0)
            {
                MessageBox.Show("原等式无解！");
            }
            else
            {
                show_ans_pic(eq.Answers[0]);
                ans_text.Text = eq.Answers[0];
            }

            ans_num.Text = "共 " + eq.Answers.Count + " 个解";
            time.Text = "搜索用时 " + sw1.Elapsed + " 秒";

            //解锁
            this.nextAns.Enabled = true;
        }

        private void text_show_TextChanged(object sender, EventArgs e)
        {

        }

        int i = 1;
        private void nextAns_Click(object sender, EventArgs e)
        {
            if (eq.Answers.Count == 0)
            {
                MessageBox.Show("原等式无解！");
            }
            else if (eq.Answers.Count == i)
            {
                show_ans_pic(eq.Answers[i-1]);
                ans_text.Text = eq.Answers[i - 1];
                MessageBox.Show("已是最后一条!");
            }
            else
            {
                show_ans_pic(eq.Answers[i]);
                ans_text.Text = eq.Answers[i];
                i++;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)  //确定输入，判断等式是否合法
        {
            clear_ans();
            int flag=0;
            string getstr = que_text.Text;
            //输入等式过长
            if (getstr.Length > 8)
            {
                flag = 1;
                MessageBox.Show("请输入2个两位以内正数相加/减/乘得两位数的等式！");
            }
            else { }
            //无等号
            if (!getstr.Contains('='))
            {
                flag = 1;
                MessageBox.Show("请输入合法等式！");
            }
            else { }
            char[] cgs=new char[10];
            cgs = getstr.ToCharArray(0, getstr.Length);
            //非法字符
            for (int i = 0; i < getstr.Length; i++)
            {
                if ((cgs[i] >= '0' && cgs[i] <= '9') || cgs[i] == '+' || cgs[i] == '-' || cgs[i] == '*' || cgs[i] == '=')
                {
                }
                else
                {
                    flag = 1;
                    MessageBox.Show("请输入2个两位以内正数相加/减/乘得两位数的等式！");
                    break;
                }
            }
            if (flag == 0)
            {
                eq.ss = que_text.Text;
                show_que_pic(eq.ss);
            }
            else 
            {
                eq.ss = "";
            }
        }

        private void bkt_menu_Click(object sender, EventArgs e)
        {
            this.Hide();
            menu nm = new menu();
            nm.ShowDialog(this);

        }

        //题库
        private void fromdb_Click(object sender, EventArgs e)
        {
            if (mode == 2 || mode == 3)
            {
                i = 1;
                eq.Answers.Clear();
                //锁定按键
                mode = 1;
                this.que_text.Enabled = false;
                this.btn_yes.Enabled = false;
                this.que_text.Text = "非自主出题模式";
                this.modetxt.Text = "当前为题库出题";
                this.level.Enabled = true;
                //清空
                clear_ans();
                this.ans_text.Text = "";
                time.Text = "";
                ans_num.Text = "";
                //展示题目
                if (level.SelectedItem.ToString() == "低")
                {
                    eq.ss = Que_low[0];
                    show_que_pic(Que_low[0]);
                }
                else if (level.SelectedItem.ToString() == "中")
                {
                    eq.ss = Que_mid[0];
                    show_que_pic(Que_mid[0]);
                }
                else if (level.SelectedItem.ToString() == "高")
                {
                    eq.ss = Que_high[0];
                    show_que_pic(Que_high[0]);
                }
                else { }
            }
            else { }
        }

        //自主
        private void fromself_Click(object sender, EventArgs e)
        {
            
            if (mode == 1 || mode == 3)
            {
                i = 1;
                eq.Answers.Clear();
                //锁定设置
                mode = 2;
                this.que_text.Enabled = true;
                this.btn_yes.Enabled = true;
                this.que_text.Text = "请输入等式";
                this.modetxt.Text = "当前由用户输入";
                this.level.Enabled = false;
                //清空
                clear_que();
                clear_ans();
                this.ans_text.Text = "";
                time.Text = "";
                ans_num.Text = "";
            }
            else { }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        //下一题
        private void nextq_Click(object sender, EventArgs e)
        {
            ans_num.Text = "";
            time.Text = "";
            eq.Answers.Clear();
            i = 1;
            sw1.Reset();

            //首先判断模式
            //题库           
            if (mode == 1)
            {
                if (level.SelectedItem.ToString() == "低")
                {
                    qn_low++;
                    if (qn_low < Que_low.Count)
                    {
                        this.ans_text.Text = "";
                        clear_que();
                        clear_ans();
                        eq.ss = Que_low[qn_low];
                        show_que_pic(Que_low[qn_low]);
                    }
                    else
                    {
                        MessageBox.Show("已是该难度下最后一题！");
                    }
                }
                else if (level.SelectedItem.ToString() == "中")
                {
                    
                    if (qn_mid < Que_mid.Count)
                    {
                        this.ans_text.Text = "";
                        clear_que();
                        clear_ans();
                        eq.ss = Que_mid[qn_mid];
                        show_que_pic(Que_mid[qn_mid]);
                    }
                    else
                    {
                        MessageBox.Show("已是该难度下最后一题！");
                    }
                    qn_mid++;
                }
                else if (level.SelectedItem.ToString() == "高")
                {
                    
                    if (qn_high < Que_high.Count)
                    {
                        this.ans_text.Text = "";
                        clear_que();
                        clear_ans();
                        eq.ss = Que_high[qn_high];
                        show_que_pic(Que_high[qn_high]);
                    }
                    else
                    {
                        MessageBox.Show("已是该难度下最后一题！");
                    }
                    qn_high++;
                }
                else { }
            }
            //自主
            else if (mode == 2)
            {
                //清空
                this.que_text.Text = "";
                this.ans_text.Text = "";
                clear_que();
                clear_ans();
            }
            //随机
            else if (mode == 3)
            {
                clear_ans();
                this.ans_text.Text = "";
                if (level.SelectedItem.ToString() == "低")
                {
                    eq.ss = random_equal(10, 10, 10);
                    show_que_pic(eq.ss);
                }
                else if (level.SelectedItem.ToString() == "中")
                {
                    eq.ss = random_equal(100, 10, 100);
                    show_que_pic(eq.ss);
                }
                else if (level.SelectedItem.ToString() == "高")
                {
                    eq.ss = random_equal(100, 100, 100);
                    show_que_pic(eq.ss);
                }
                else { }
            }
            else { }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        //随机模式
        private void button1_Click_1(object sender, EventArgs e)
        {
            
            if (mode == 2 || mode == 1)
            {
                i = 1;
                eq.Answers.Clear();
                //锁定按键
                mode = 3;
                this.que_text.Enabled = false;
                this.btn_yes.Enabled = false;
                this.que_text.Text = "非自主出题模式";
                this.modetxt.Text = "当前为随机出题";
                this.level.Enabled = true;
                //清空
                clear_ans();
                clear_que();
                this.ans_text.Text = "";
                time.Text = "";
                ans_num.Text = "";
                //展示题目
                if (level.SelectedItem.ToString() == "低")
                {
                    eq.ss = random_equal(10, 10, 10);
                    show_que_pic(eq.ss);
                }
                else if (level.SelectedItem.ToString() == "中")
                {
                    eq.ss = random_equal(100, 10, 100);
                    show_que_pic(eq.ss);
                }
                else if (level.SelectedItem.ToString() == "高")
                {
                    eq.ss = random_equal(100, 100, 100);
                    show_que_pic(eq.ss);
                }
                else { }
            }
            else { }
        }

        //随机生成等式
        public string random_equal(int max1, int max2, int max3)
        {
            //随机生成
            string firn;
            string secn;
            string calc;
            string resn;
            Equal equal = new Equal();
            Random rnd = new Random();
            while (true)
            {
                firn = rnd.Next(0, max1).ToString();
                secn = rnd.Next(0, max2).ToString();
                resn = rnd.Next(0, max3).ToString();
                calc = rnd.Next(10, 13).ToString();
                switch (calc)
                {
                    case "10":
                        calc = "+";
                        break;
                    case "11":
                        calc = "-";
                        break;
                    case "12":
                        calc = "*";
                        break;
                }
                equal.ss = firn + calc + secn + "=" + resn;
                equal.str_route = equal.ss;
                equal.getdata_one();
                equal.split(equal.ss);
                equal.solvedfs(0);
                if (equal.Answers.Count() > 0)
                {
                    break;
                }
            }
            return equal.ss;
        }

        private void move_num_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (move_num.SelectedItem.ToString() == "两根")
            {
                radioButton_for.Checked = true;
                radioButton_dfs.Enabled = false;
            }
            else
            {
                radioButton_dfs.Enabled = true;
            }
        }
    }
}
