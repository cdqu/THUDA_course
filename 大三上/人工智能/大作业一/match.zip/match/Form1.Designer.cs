﻿namespace match
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSolve = new System.Windows.Forms.Button();
            this.que_text = new System.Windows.Forms.TextBox();
            this.ans_text = new System.Windows.Forms.TextBox();
            this.nextAns = new System.Windows.Forms.Button();
            this.PB1 = new System.Windows.Forms.PictureBox();
            this.btn_yes = new System.Windows.Forms.Button();
            this.PB2 = new System.Windows.Forms.PictureBox();
            this.PB3 = new System.Windows.Forms.PictureBox();
            this.PB4 = new System.Windows.Forms.PictureBox();
            this.PB5 = new System.Windows.Forms.PictureBox();
            this.PB6 = new System.Windows.Forms.PictureBox();
            this.PB7 = new System.Windows.Forms.PictureBox();
            this.PB8 = new System.Windows.Forms.PictureBox();
            this.bkt_menu = new System.Windows.Forms.Button();
            this.skinEngine1 = new Sunisoft.IrisSkin.SkinEngine(((System.ComponentModel.Component)(this)));
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.move_num = new System.Windows.Forms.ComboBox();
            this.level = new System.Windows.Forms.ComboBox();
            this.fromdb = new System.Windows.Forms.Button();
            this.fromself = new System.Windows.Forms.Button();
            this.nextq = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.modetxt = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ans_num = new System.Windows.Forms.Label();
            this.time = new System.Windows.Forms.Label();
            this.random = new System.Windows.Forms.Button();
            this.radioButton_for = new System.Windows.Forms.RadioButton();
            this.radioButton_dfs = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.PB1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSolve
            // 
            this.btnSolve.Location = new System.Drawing.Point(604, 108);
            this.btnSolve.Name = "btnSolve";
            this.btnSolve.Size = new System.Drawing.Size(125, 40);
            this.btnSolve.TabIndex = 0;
            this.btnSolve.Text = "求解";
            this.btnSolve.UseVisualStyleBackColor = true;
            this.btnSolve.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // que_text
            // 
            this.que_text.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que_text.Location = new System.Drawing.Point(123, 108);
            this.que_text.Multiline = true;
            this.que_text.Name = "que_text";
            this.que_text.Size = new System.Drawing.Size(191, 39);
            this.que_text.TabIndex = 1;
            this.que_text.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // ans_text
            // 
            this.ans_text.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ans_text.Location = new System.Drawing.Point(123, 340);
            this.ans_text.Multiline = true;
            this.ans_text.Name = "ans_text";
            this.ans_text.Size = new System.Drawing.Size(191, 39);
            this.ans_text.TabIndex = 2;
            this.ans_text.TextChanged += new System.EventHandler(this.text_show_TextChanged);
            // 
            // nextAns
            // 
            this.nextAns.Location = new System.Drawing.Point(604, 340);
            this.nextAns.Name = "nextAns";
            this.nextAns.Size = new System.Drawing.Size(125, 39);
            this.nextAns.TabIndex = 3;
            this.nextAns.Text = "下一个解";
            this.nextAns.UseVisualStyleBackColor = true;
            this.nextAns.Click += new System.EventHandler(this.nextAns_Click);
            // 
            // PB1
            // 
            this.PB1.Location = new System.Drawing.Point(65, 168);
            this.PB1.Name = "PB1";
            this.PB1.Size = new System.Drawing.Size(83, 113);
            this.PB1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB1.TabIndex = 4;
            this.PB1.TabStop = false;
            this.PB1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btn_yes
            // 
            this.btn_yes.Location = new System.Drawing.Point(320, 108);
            this.btn_yes.Name = "btn_yes";
            this.btn_yes.Size = new System.Drawing.Size(92, 39);
            this.btn_yes.TabIndex = 5;
            this.btn_yes.Text = "确定";
            this.btn_yes.UseVisualStyleBackColor = true;
            this.btn_yes.Click += new System.EventHandler(this.button1_Click);
            // 
            // PB2
            // 
            this.PB2.Location = new System.Drawing.Point(148, 168);
            this.PB2.Name = "PB2";
            this.PB2.Size = new System.Drawing.Size(83, 113);
            this.PB2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB2.TabIndex = 6;
            this.PB2.TabStop = false;
            // 
            // PB3
            // 
            this.PB3.Location = new System.Drawing.Point(231, 168);
            this.PB3.Name = "PB3";
            this.PB3.Size = new System.Drawing.Size(83, 113);
            this.PB3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB3.TabIndex = 7;
            this.PB3.TabStop = false;
            // 
            // PB4
            // 
            this.PB4.Location = new System.Drawing.Point(313, 168);
            this.PB4.Name = "PB4";
            this.PB4.Size = new System.Drawing.Size(83, 113);
            this.PB4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB4.TabIndex = 8;
            this.PB4.TabStop = false;
            // 
            // PB5
            // 
            this.PB5.Location = new System.Drawing.Point(396, 168);
            this.PB5.Name = "PB5";
            this.PB5.Size = new System.Drawing.Size(83, 113);
            this.PB5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB5.TabIndex = 9;
            this.PB5.TabStop = false;
            // 
            // PB6
            // 
            this.PB6.Location = new System.Drawing.Point(479, 168);
            this.PB6.Name = "PB6";
            this.PB6.Size = new System.Drawing.Size(83, 113);
            this.PB6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB6.TabIndex = 10;
            this.PB6.TabStop = false;
            // 
            // PB7
            // 
            this.PB7.Location = new System.Drawing.Point(561, 168);
            this.PB7.Name = "PB7";
            this.PB7.Size = new System.Drawing.Size(83, 113);
            this.PB7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB7.TabIndex = 11;
            this.PB7.TabStop = false;
            // 
            // PB8
            // 
            this.PB8.Location = new System.Drawing.Point(644, 168);
            this.PB8.Name = "PB8";
            this.PB8.Size = new System.Drawing.Size(83, 113);
            this.PB8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB8.TabIndex = 12;
            this.PB8.TabStop = false;
            // 
            // bkt_menu
            // 
            this.bkt_menu.Location = new System.Drawing.Point(824, 473);
            this.bkt_menu.Name = "bkt_menu";
            this.bkt_menu.Size = new System.Drawing.Size(125, 40);
            this.bkt_menu.TabIndex = 13;
            this.bkt_menu.Text = "返回主菜单";
            this.bkt_menu.UseVisualStyleBackColor = true;
            this.bkt_menu.Click += new System.EventHandler(this.bkt_menu_Click);
            // 
            // skinEngine1
            // 
            this.skinEngine1.SerialNumber = "";
            this.skinEngine1.SkinFile = null;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Location = new System.Drawing.Point(644, 428);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(83, 113);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 21;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Location = new System.Drawing.Point(561, 428);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(83, 113);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 20;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Location = new System.Drawing.Point(479, 428);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(83, 113);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 19;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Location = new System.Drawing.Point(396, 428);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(83, 113);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 18;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Location = new System.Drawing.Point(313, 428);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(83, 113);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 17;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Location = new System.Drawing.Point(231, 428);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(83, 113);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 16;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Location = new System.Drawing.Point(148, 428);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(83, 113);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 15;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Location = new System.Drawing.Point(65, 428);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(83, 113);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 14;
            this.pictureBox9.TabStop = false;
            // 
            // move_num
            // 
            this.move_num.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.move_num.FormattingEnabled = true;
            this.move_num.Items.AddRange(new object[] {
            "一根",
            "两根"});
            this.move_num.Location = new System.Drawing.Point(868, 210);
            this.move_num.Name = "move_num";
            this.move_num.Size = new System.Drawing.Size(81, 23);
            this.move_num.TabIndex = 22;
            this.move_num.SelectedIndexChanged += new System.EventHandler(this.move_num_SelectedIndexChanged);
            // 
            // level
            // 
            this.level.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.level.FormattingEnabled = true;
            this.level.Items.AddRange(new object[] {
            "低",
            "中",
            "高"});
            this.level.Location = new System.Drawing.Point(868, 94);
            this.level.Name = "level";
            this.level.Size = new System.Drawing.Size(81, 23);
            this.level.TabIndex = 23;
            // 
            // fromdb
            // 
            this.fromdb.Location = new System.Drawing.Point(231, 33);
            this.fromdb.Name = "fromdb";
            this.fromdb.Size = new System.Drawing.Size(125, 40);
            this.fromdb.TabIndex = 24;
            this.fromdb.Text = "题库出题";
            this.fromdb.UseVisualStyleBackColor = true;
            this.fromdb.Click += new System.EventHandler(this.fromdb_Click);
            // 
            // fromself
            // 
            this.fromself.Location = new System.Drawing.Point(362, 33);
            this.fromself.Name = "fromself";
            this.fromself.Size = new System.Drawing.Size(125, 40);
            this.fromself.TabIndex = 25;
            this.fromself.Text = "自主出题";
            this.fromself.UseVisualStyleBackColor = true;
            this.fromself.Click += new System.EventHandler(this.fromself_Click);
            // 
            // nextq
            // 
            this.nextq.Location = new System.Drawing.Point(824, 336);
            this.nextq.Name = "nextq";
            this.nextq.Size = new System.Drawing.Size(125, 40);
            this.nextq.TabIndex = 26;
            this.nextq.Text = "下一题";
            this.nextq.UseVisualStyleBackColor = true;
            this.nextq.Click += new System.EventHandler(this.nextq_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(61, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 19);
            this.label1.TabIndex = 27;
            this.label1.Text = "请选择游戏模式：";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // modetxt
            // 
            this.modetxt.AutoSize = true;
            this.modetxt.Font = new System.Drawing.Font("宋体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.modetxt.Location = new System.Drawing.Point(650, 44);
            this.modetxt.Name = "modetxt";
            this.modetxt.Size = new System.Drawing.Size(0, 19);
            this.modetxt.TabIndex = 28;
            this.modetxt.Click += new System.EventHandler(this.label2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(777, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 19);
            this.label2.TabIndex = 29;
            this.label2.Text = "难度等级";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(777, 214);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 19);
            this.label3.TabIndex = 30;
            this.label3.Text = "移动根数";
            // 
            // ans_num
            // 
            this.ans_num.AutoSize = true;
            this.ans_num.Font = new System.Drawing.Font("宋体", 10F);
            this.ans_num.Location = new System.Drawing.Point(340, 329);
            this.ans_num.Name = "ans_num";
            this.ans_num.Size = new System.Drawing.Size(0, 17);
            this.ans_num.TabIndex = 31;
            this.ans_num.Click += new System.EventHandler(this.label4_Click);
            // 
            // time
            // 
            this.time.AutoSize = true;
            this.time.Font = new System.Drawing.Font("宋体", 10F);
            this.time.Location = new System.Drawing.Point(340, 380);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(0, 17);
            this.time.TabIndex = 32;
            // 
            // random
            // 
            this.random.Location = new System.Drawing.Point(493, 33);
            this.random.Name = "random";
            this.random.Size = new System.Drawing.Size(125, 40);
            this.random.TabIndex = 33;
            this.random.Text = "随机出题";
            this.random.UseVisualStyleBackColor = true;
            this.random.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // radioButton_for
            // 
            this.radioButton_for.AutoSize = true;
            this.radioButton_for.Location = new System.Drawing.Point(451, 98);
            this.radioButton_for.Name = "radioButton_for";
            this.radioButton_for.Size = new System.Drawing.Size(82, 19);
            this.radioButton_for.TabIndex = 36;
            this.radioButton_for.TabStop = true;
            this.radioButton_for.Text = "for循环";
            this.radioButton_for.UseVisualStyleBackColor = true;
            // 
            // radioButton_dfs
            // 
            this.radioButton_dfs.AutoSize = true;
            this.radioButton_dfs.Location = new System.Drawing.Point(451, 129);
            this.radioButton_dfs.Name = "radioButton_dfs";
            this.radioButton_dfs.Size = new System.Drawing.Size(88, 19);
            this.radioButton_dfs.TabIndex = 37;
            this.radioButton_dfs.TabStop = true;
            this.radioButton_dfs.Text = "递归搜索";
            this.radioButton_dfs.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(998, 600);
            this.Controls.Add(this.radioButton_dfs);
            this.Controls.Add(this.radioButton_for);
            this.Controls.Add(this.random);
            this.Controls.Add(this.time);
            this.Controls.Add(this.ans_num);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.modetxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nextq);
            this.Controls.Add(this.fromself);
            this.Controls.Add(this.fromdb);
            this.Controls.Add(this.level);
            this.Controls.Add(this.move_num);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.bkt_menu);
            this.Controls.Add(this.PB8);
            this.Controls.Add(this.PB7);
            this.Controls.Add(this.PB6);
            this.Controls.Add(this.PB5);
            this.Controls.Add(this.PB4);
            this.Controls.Add(this.PB3);
            this.Controls.Add(this.PB2);
            this.Controls.Add(this.btn_yes);
            this.Controls.Add(this.PB1);
            this.Controls.Add(this.nextAns);
            this.Controls.Add(this.ans_text);
            this.Controls.Add(this.que_text);
            this.Controls.Add(this.btnSolve);
            this.Name = "Form1";
            this.Text = "火柴棍";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PB1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSolve;
        private System.Windows.Forms.TextBox que_text;
        public System.Windows.Forms.TextBox ans_text;
        private System.Windows.Forms.Button nextAns;
        private System.Windows.Forms.PictureBox PB1;
        private System.Windows.Forms.Button btn_yes;
        private System.Windows.Forms.PictureBox PB2;
        private System.Windows.Forms.PictureBox PB3;
        private System.Windows.Forms.PictureBox PB4;
        private System.Windows.Forms.PictureBox PB5;
        private System.Windows.Forms.PictureBox PB6;
        private System.Windows.Forms.PictureBox PB7;
        private System.Windows.Forms.PictureBox PB8;
        private System.Windows.Forms.Button bkt_menu;
        private Sunisoft.IrisSkin.SkinEngine skinEngine1;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.ComboBox move_num;
        private System.Windows.Forms.ComboBox level;
        private System.Windows.Forms.Button fromdb;
        private System.Windows.Forms.Button fromself;
        private System.Windows.Forms.Button nextq;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label modetxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label ans_num;
        private System.Windows.Forms.Label time;
        private System.Windows.Forms.Button random;
        private System.Windows.Forms.RadioButton radioButton_for;
        private System.Windows.Forms.RadioButton radioButton_dfs;

    }
}

