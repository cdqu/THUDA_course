﻿namespace match
{
    partial class menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.start = new System.Windows.Forms.Button();
            this.help = new System.Windows.Forms.Button();
            this.leave = new System.Windows.Forms.Button();
            this.skinEngine1 = new Sunisoft.IrisSkin.SkinEngine(((System.ComponentModel.Component)(this)));
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("楷体", 42F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(72, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(385, 70);
            this.label1.TabIndex = 0;
            this.label1.Text = "巧移火柴棍";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // start
            // 
            this.start.Location = new System.Drawing.Point(124, 184);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(100, 34);
            this.start.TabIndex = 1;
            this.start.Text = "开始游戏";
            this.start.UseVisualStyleBackColor = true;
            this.start.Click += new System.EventHandler(this.start_Click);
            // 
            // help
            // 
            this.help.Location = new System.Drawing.Point(124, 255);
            this.help.Name = "help";
            this.help.Size = new System.Drawing.Size(100, 34);
            this.help.TabIndex = 2;
            this.help.Text = "游戏玩法";
            this.help.UseVisualStyleBackColor = true;
            this.help.Click += new System.EventHandler(this.help_Click);
            // 
            // leave
            // 
            this.leave.Location = new System.Drawing.Point(124, 326);
            this.leave.Name = "leave";
            this.leave.Size = new System.Drawing.Size(100, 34);
            this.leave.TabIndex = 3;
            this.leave.Text = "退出";
            this.leave.UseVisualStyleBackColor = true;
            this.leave.Click += new System.EventHandler(this.leave_Click);
            // 
            // skinEngine1
            // 
            this.skinEngine1.SerialNumber = "";
            this.skinEngine1.SkinFile = null;
            // 
            // menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HighlightText;
            this.BackgroundImage = global::match.Properties.Resources.menu_bg;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(703, 499);
            this.Controls.Add(this.leave);
            this.Controls.Add(this.help);
            this.Controls.Add(this.start);
            this.Controls.Add(this.label1);
            this.Name = "menu";
            this.Text = "开始菜单";
            this.Load += new System.EventHandler(this.menu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button start;
        private System.Windows.Forms.Button help;
        private System.Windows.Forms.Button leave;
        private Sunisoft.IrisSkin.SkinEngine skinEngine1;
    }
}