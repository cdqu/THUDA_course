﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace match
{
    public partial class menu : Form
    {
        public menu()
        {
            InitializeComponent();
            skinEngine1.SkinFile = Application.StartupPath + "//DeepCyan.ssk";
        }

        private void menu_Load(object sender, EventArgs e)
        {
            this.skinEngine1 = new Sunisoft.IrisSkin.SkinEngine(((System.ComponentModel.Component)(this)));
            skinEngine1.SkinFile = Application.StartupPath + "//DeepCyan.ssk";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void start_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();            
            f1.ShowDialog(this);
            this.Close();
        }

        private void help_Click(object sender, EventArgs e)
        {
            MessageBox.Show("巧移火柴棍：移动火柴使等式成立，玩家可以选择题库出题、自主出题\n或游戏随机出题，游戏有低中高三种难度分级，可以选择移动一根或两根，\n可点击【求解】查看解答。点击【下一题】进入下一道题。", "Help");
        }

        private void leave_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
