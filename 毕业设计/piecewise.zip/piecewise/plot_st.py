#!/usr/bin/env python
import math
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import pandas as pd
import numpy as np
import os
pwd = os.getcwd()

input_txt = '/home/qucd/Documents/piecewise/plot_st.txt'
x = []
y = []

f = open(input_txt)

for line in f:
    line = line.strip('\n')
    line = line.split(' ')

    x.append(float(line[0]))
    y.append(float(line[1]))

f.close


fig = plt.figure()
ax1 = fig.add_subplot(111)
ax1.plot(x, y, linewidth = 1.0, color = 'r', label = 'Trapezoidal Corridor')
ax1.legend(loc = 1)
#ax1.plot(xr, yr, linewidth = 1.0, color = 'b', label = 'Rectangular Corridor')
#ax1.legend(loc = 2)
ax1.set_xlabel("t / s")
ax1.set_ylabel("s / m")
plt.title("Piecewise Bezier Curve with Corridors")

obs1_x = [2.0, 4.5, 4.5, 2.0]
obs1_y = [34, 41.5, 60, 52.5]

ax1.add_patch(patches.Polygon(xy=list(zip(obs1_x,obs1_y)), fill=True))

obs2_x = [4.0, 6.0, 6.0, 4.0]
obs2_y = [25, 45, 30, 10]

ax1.add_patch(patches.Polygon(xy=list(zip(obs2_x,obs2_y)), fill=True))

plt.savefig('/home/qucd/Documents/piecewise/bezier_curve')

plt.show()
