#include "piecewise_jerk_speed_problem.h"
#include "logging.h"
#include <math.h>
#include <iostream>

using namespace Eigen;
using namespace std;

namespace navigation {

PiecewiseJerkSpeedProblem::PiecewiseJerkSpeedProblem(
    const size_t num_of_knots, const double delta_s,
    const std::array<double, 3>& x_init)
    : PiecewiseJerkProblem(num_of_knots, delta_s, x_init) {

    penalty_dx_.resize(num_of_knots_, 0.0);
    const int n = static_cast<int>(num_of_knots_);
    segment_num = n / 10;

    traj_order = 5;
    n_poly = traj_order + 1;
    n_of_knots = segment_num * 10;
}

void PiecewiseJerkSpeedProblem::set_dx_ref(const double weight_dx_ref,
                                           const double dx_ref) {
    weight_dx_ref_ = weight_dx_ref;
    dx_ref_ = dx_ref;
    has_dx_ref_ = true;
}

void PiecewiseJerkSpeedProblem::set_penalty_dx(std::vector<double> penalty_dx) {
    CHECK_EQ(penalty_dx.size(), num_of_knots_);
    penalty_dx_ = std::move(penalty_dx);
}

void PiecewiseJerkSpeedProblem::CalculateKernel(std::vector<c_float>* P_data,
                                                std::vector<c_int>* P_indices,
                                                std::vector<c_int>* P_indptr) {
  MatrixXd pQp ;
  pQp = MatrixXd::Zero(n_poly, n_poly);

    for(int i = 0; i < n_poly; i++ )
    {
      for(int j = 0; j < n_poly; j++ )
      {
	  //cout << weight_x_ref_ << endl;
          pQp(i,j) += double(weight_x_ref_)/(i + j + 1);


        if(i >= 1 && j >= 1 )
        {
          pQp (i,j) += double((weight_dx_ref_ + penalty_dx_[i]) * i * j) / (i + j - 1);

          if(i >= 2 && j >= 2 )
          {  
              pQp (i,j) += double(weight_ddx_ * i * j * (i - 1) * (j - 1)) / (i + j - 3);

              if(i >= 3 && j >= 3 )
              {   
                pQp (i,j) += double(weight_dddx_ * i * j * (i - 1) * (j - 1) * (i - 2) * (j - 2)) / (i + j - 5);

              }
          }
        }   
      }
    }

  MatrixXd MQM;

  M.resize(n_poly, n_poly);

  M << 1,   0,   0,   0,  0,  0,
          -5,   5,   0,   0,  0,  0,
          10, -20,  10,   0,  0,  0,
           -10,  30, -30,  10,  0,  0,
             5, -20,  30, -20,  5,  0,
            -1,   5, -10,  10, -5,  1;

  MQM = M.transpose() * pQp * M;

  int idx = 0;
  int sub_shift = 0;

  for(int k = 0; k < segment_num; k ++)
  {
    for(int j = 0; j < n_poly; j++ )
    {
      P_indptr -> push_back(idx);

      for(int i = 0; i < n_poly; i++ )
      {
        if( j >= i )
        {
          P_indices -> push_back(sub_shift + i);
          P_data -> push_back(2.0 * MQM(i,j));
          idx ++;
        }

      }
    }
    sub_shift += n_poly;
  }
  P_indptr -> push_back(idx);
}

void PiecewiseJerkSpeedProblem::CalculateOffset(std::vector<c_float>* q) {
  CHECK_NOTNULL(q);
  q->resize(segment_num * n_poly, 0.0);
  
  MatrixXd q_p, q_c;
  
  q_p = MatrixXd::Zero(1, n_poly);
  
  int p_shift = 0;
  
 for (int k = 0; k < segment_num; k++ ){
  
    for (int i = 0; i < n_poly; i++ ){   
    q_p(0, i) = 0.0;
    
    if(has_x_ref_){

    q_p(0, i) += -2.0 * weight_x_ref_ * x_skew_[k]/(i + 2);
    q_p(0, i) += -2.0 * weight_x_ref_ * x_bias_[k]/(i + 1);

    }

    if (has_dx_ref_ && i > 0) {

        q_p(0, i) += -2.0 * weight_dx_ref_ * dx_ref_ ;
    }
  
  }
    q_c = q_p * M;

    for (int i = 0; i < n_poly; i++ ){
      q -> at(p_shift + i) = double(q_c(0, i));
    }
    p_shift += n_poly;
  }
}

void PiecewiseJerkSpeedProblem::CalculateAffineConstraint(
    std::vector<c_float>* A_data, std::vector<c_int>* A_indices,
    std::vector<c_int>* A_indptr, std::vector<c_float>* lower_bounds,
    std::vector<c_float>* upper_bounds) {
    
    int num_of_constraints = segment_num * (3 * n_poly - 3) + 3 + 3 * (segment_num -1) + 2;

    int num_of_variables = segment_num * n_poly;

    vector< vector < pair <c_int,c_float> >> variables(segment_num * n_poly);
    

    double aval[3];
    aval[0] = 1.0 * traj_order * (traj_order - 1);
    aval[1] = -2.0 * traj_order * (traj_order - 1);
    aval[2] =  1.0 * traj_order * (traj_order - 1);

    lower_bounds->resize(num_of_constraints);
    upper_bounds->resize(num_of_constraints);

    int var_shift = 0;
    int bound_shift = 0;
    int constraint_index = 0;

    for (int k = 0; k < segment_num; k++)
    {   
        double x_lower_bound = 0.0, x_upper_bound = 1000.0;
        double dx_lower_bound = 0.0, dx_upper_bound = 1000.0;
        double ddx_lower_bound = -1000.0, ddx_upper_bound = 1000.0;
        
        for(int l = 0; l < 11; l ++)
        {
          x_lower_bound = max(x_bounds_[bound_shift + l].first, x_lower_bound);
          x_upper_bound = min(x_bounds_[bound_shift + l].second, x_upper_bound);

          dx_lower_bound = max(dx_bounds_[bound_shift + l].first, dx_lower_bound);
          dx_upper_bound = min(dx_bounds_[bound_shift + l].second, dx_upper_bound);

          ddx_lower_bound = max(ddx_bounds_[bound_shift + l].first, ddx_lower_bound);
          ddx_upper_bound = min(ddx_bounds_[bound_shift + l].second, ddx_upper_bound);
        }

        bound_shift += 10;
	cout << k;
        cout << " x_lower_bound: " << x_lower_bound;
        cout << " x_upper_bound: " << x_upper_bound << std::endl;
        // ofs_boundary << k << "1_ddx_lower_bound: " << ddx_lower_bound << std::endl;
        // ofs_boundary << k << "2_ddx_upper_bound: " << ddx_upper_bound << std::endl;

        for (int i = 0; i < n_poly; i++){
        variables[var_shift + i].emplace_back(constraint_index, 1.0);
        lower_bounds->at(constraint_index) = x_lower_bound;
        upper_bounds->at(constraint_index) = x_upper_bound;
        ++constraint_index;
        }

        for (int i = 0; i < n_poly -1; i++){
        variables[var_shift + i].emplace_back(constraint_index, - 1.0 * traj_order);
        variables[var_shift + i + 1].emplace_back(constraint_index, 1.0 * traj_order);       
        
        lower_bounds->at(constraint_index) = dx_lower_bound;
        upper_bounds->at(constraint_index) = dx_upper_bound;
        ++constraint_index;
        }

        for (int i = 0; i < n_poly -2; i++){
        variables[var_shift + i].emplace_back(constraint_index, aval[0]);
        variables[var_shift + i + 1].emplace_back(constraint_index, aval[1]);
        variables[var_shift + i + 2].emplace_back(constraint_index, aval[2]);
        
        lower_bounds->at(constraint_index) = ddx_lower_bound;
        upper_bounds->at(constraint_index) = ddx_upper_bound;
        ++constraint_index;
        }
        var_shift += n_poly;
    }
      
    /*   Start position  */
  variables[0].emplace_back(constraint_index, 1.0);
  lower_bounds->at(constraint_index) = x_init_[0];
  upper_bounds->at(constraint_index) = x_init_[0];
  ++constraint_index;

  variables[0].emplace_back(constraint_index, - 1.0 * traj_order);
  variables[1].emplace_back(constraint_index, 1.0 * traj_order);
  lower_bounds->at(constraint_index) = x_init_[1];
  upper_bounds->at(constraint_index) = x_init_[1];
  ++constraint_index;

  variables[0].emplace_back(constraint_index, aval[0]);
  variables[1].emplace_back(constraint_index, aval[1]);
  variables[2].emplace_back(constraint_index, aval[2]);
  lower_bounds->at(constraint_index) = x_init_[2];
  upper_bounds->at(constraint_index) = x_init_[2];
  ++constraint_index;
  
  int end_index = segment_num * n_poly - 1;
  
  variables[end_index].emplace_back(constraint_index, 1.0);
  lower_bounds->at(constraint_index) = x_ref_[n_of_knots];
  upper_bounds->at(constraint_index) = x_ref_[n_of_knots];
  ++constraint_index;

  variables[end_index - 1].emplace_back(constraint_index, - 1.0 * traj_order);
  variables[end_index].emplace_back(constraint_index, 1.0 * traj_order);
  lower_bounds->at(constraint_index) = x_skew_[segment_num - 1];
  upper_bounds->at(constraint_index) = x_skew_[segment_num - 1];
  ++constraint_index;

  /*   joint points  */
  int sub_shift = 0;
  
  for(int k = 0; k < (segment_num - 1); k ++ ){
  sub_shift = (k + 1) * n_poly;
  variables[sub_shift - 1].emplace_back(constraint_index, - 1.0);
  variables[sub_shift].emplace_back(constraint_index, 1.0);
  lower_bounds->at(constraint_index) = 0.0;
  upper_bounds->at(constraint_index) = 0.0;
  ++constraint_index;

  variables[sub_shift-2].emplace_back(constraint_index, -1.0);
  variables[sub_shift-1].emplace_back(constraint_index, 1.0);
  variables[sub_shift].emplace_back(constraint_index, 1.0);
  variables[sub_shift+1].emplace_back(constraint_index, -1.0);
  lower_bounds->at(constraint_index) = 0.0;
  upper_bounds->at(constraint_index) = 0.0;
  constraint_index ++;

  variables[sub_shift-3].emplace_back(constraint_index, 1.0);
  variables[sub_shift-2].emplace_back(constraint_index, -2.0);
  variables[sub_shift-1].emplace_back(constraint_index, 1.0);
  variables[sub_shift].emplace_back(constraint_index, -1.0);
  variables[sub_shift+1].emplace_back(constraint_index, 2.0);
  variables[sub_shift+2].emplace_back(constraint_index, -1.0);
  
  lower_bounds->at(constraint_index) = 0.0;
  upper_bounds->at(constraint_index) = 0.0;
  constraint_index ++;
  }
  CHECK_EQ(constraint_index, num_of_constraints);

  int ind_p = 0;
  for (int i = 0; i < num_of_variables; ++i) {
    A_indptr->push_back(ind_p);
    for (const auto& variable_nz : variables[i]) {
      // coefficient
      A_data->push_back(variable_nz.second);

      // constraint index
      A_indices->push_back(variable_nz.first);
      ++ind_p;
    }
  }
  // We indeed need this line because of
  // https://github.com/oxfordcontrol/osqp/blob/master/src/cs.c#L255
  A_indptr->push_back(ind_p);


}

OSQPData* PiecewiseJerkSpeedProblem::FormulateProblem() {
  // calculate kernel
  x_skew_.resize(segment_num);
  x_bias_.resize(segment_num);
  for(int k = 0; k < segment_num; k++){
    x_skew_[k] = (x_ref_[k * 10 + 1] - x_ref_[k * 10])/delta_s_;
    x_bias_[k] = x_ref_[k * 10];
   //cout << k <<" segment: skew " << x_skew_[k] << " bias "<< x_bias_[k] << endl;
  }
  
  std::vector<c_float> P_data;
  std::vector<c_int> P_indices;
  std::vector<c_int> P_indptr;
  //load data
  CalculateKernel(&P_data, &P_indices, &P_indptr);

  // calculate affine constraints
  std::vector<c_float> A_data;
  std::vector<c_int> A_indices;
  std::vector<c_int> A_indptr;
  std::vector<c_float> lower_bounds;
  std::vector<c_float> upper_bounds;
  CalculateAffineConstraint(&A_data, &A_indices, &A_indptr, &lower_bounds,
                            &upper_bounds);

  // calculate offset
  std::vector<c_float> q;
  CalculateOffset(&q);

  OSQPData* data = reinterpret_cast<OSQPData*>(c_malloc(sizeof(OSQPData)));
  CHECK_EQ(lower_bounds.size(), upper_bounds.size());
  
  size_t kernel_dim;
  kernel_dim = segment_num * n_poly;
  size_t num_affine_constraint = lower_bounds.size();

  data->n = kernel_dim;
  data->m = num_affine_constraint;
  data->P = csc_matrix(kernel_dim, kernel_dim, P_data.size(), CopyData(P_data),
                       CopyData(P_indices), CopyData(P_indptr));
  data->q = CopyData(q);
  data->A =
      csc_matrix(num_affine_constraint, kernel_dim, A_data.size(),
                 CopyData(A_data), CopyData(A_indices), CopyData(A_indptr));
  data->l = CopyData(lower_bounds);
  data->u = CopyData(upper_bounds);
  return data;
}

bool PiecewiseJerkSpeedProblem::Optimize(const int max_iter) {
  OSQPData* data = FormulateProblem();

  OSQPSettings* settings = SolverDefaultSettings();
  settings->max_iter = max_iter;

  OSQPWorkspace* osqp_work = nullptr;
  osqp_work = osqp_setup(data, settings); // osqp-0.4.1, 0.5.0
  // osqp_setup(&osqp_work, data, settings); // osqp-0.6.0

  osqp_solve(osqp_work);

  auto status = osqp_work->info->status_val;

  if (status < 0 || (status != 1 && status != 2)) {
    //AERROR << "failed optimization status:\t" << osqp_work->info->status;
    osqp_cleanup(osqp_work);
    FreeData(data);
    c_free(settings);
    return false;
  } else if (osqp_work->solution == nullptr) {
    //AERROR << "The solution from OSQP is nullptr";
    osqp_cleanup(osqp_work);
    FreeData(data);
    c_free(settings);
    return false;
  }


  x_.resize(num_of_knots_);
  dx_.resize(num_of_knots_);
  ddx_.resize(num_of_knots_);
  
  double factorial[6];
  factorial[0] = 1.0;

  for (int i = 1; i < n_poly; i++)
  {
    factorial[i] = factorial[i - 1] * i;
  }
  double b_coe[6][3];

  for (int i = 0; i < n_poly; i++){
    b_coe[i][0] = double (factorial[traj_order]) / (factorial[i] * factorial[traj_order - i]);
  }

  for (int i = 0; i < n_poly - 1; i++){
    b_coe[i][1] = double (factorial[traj_order - 1]) / (factorial[i] * factorial[traj_order - 1 - i]);
  }

  for (int i = 0; i < n_poly - 2; i++){
    b_coe[i][2] = double (factorial[traj_order - 2]) / (factorial[i] * factorial[traj_order - 2 - i]);
  }

  int sub_shift = 0;
  int var_index = 0;
  
  for (int k = 0; k < segment_num; ++k) {

    double c[6];
    for (int i = 0; i < n_poly; i++){
      c[i] = osqp_work->solution->x[sub_shift + i];
    }
    sub_shift += n_poly;

    //double x_max_slot = 0.0;
    for (int l = 0; l < 10; l++){
    x_.at(var_index) = 0.0;
    dx_.at(var_index) = 0.0;
    ddx_.at(var_index) = 0.0;

    for (int i = 0; i < n_poly; i++){
      x_.at(var_index) += c[i] * b_coe[i][0] * pow(l * delta_s_, i) * pow(1 - l * delta_s_, traj_order - i);
    }
    for (int i = 0; i < n_poly - 1; i++){
      dx_.at(var_index) += traj_order * (c[i+1] - c[i]) * b_coe[i][1] * pow(l * delta_s_, i) * pow(1 - l * delta_s_, traj_order - 1 - i);
    }
    for (int i = 0; i < n_poly - 2; i++){
      ddx_.at(var_index) += traj_order * (traj_order - 1) * (c[i+2] - 2.0 * c[i+1] + c[i]) * b_coe[i][2] * pow(l * delta_s_, i) * pow(1 - l * delta_s_, traj_order - 2 - i);
    }

    // std::ofstream ofs_speed("/home/ubuntu/magnavi_ws2/src/megnavi/navi_manager/src/modules/navi_local/public_road/math/piecewise_jerk/max_position.txt", 
    // std::ios::ate|std::ios::out|std::ios::in);
    // x_max_slot = max(x_max_slot, x_.at(var_index));
    // ofs_speed << k << " x_max: " << x_max_slot << std::endl;
    // x_.at(i) = osqp_work->solution->x[i] / scale_factor_[0];
    // dx_.at(i) = osqp_work->solution->x[i + num_of_knots_] / scale_factor_[1];
    // ddx_.at(i) =
    //     osqp_work->solution->x[i + 2 * num_of_knots_] / scale_factor_[2];
    var_index ++ ;
    }
  }
  CHECK_EQ(var_index, n_of_knots);
  double delta_s_sq_ = delta_s_ * delta_s_;

  const int n = static_cast<int>(num_of_knots_);
  for (int i = n_of_knots; i < n; i++)
  {
    ddx_.at(var_index) = 2 * ddx_.at(var_index - 1) - ddx_.at(var_index - 2);
    dx_.at(var_index) = dx_.at(var_index - 1) + 1/2 * ddx_.at(var_index - 1) * delta_s_ + 1/2 * ddx_.at(var_index) * delta_s_;
    x_.at(var_index) = x_.at(var_index - 1) + dx_.at(var_index - 1) * delta_s_ + 1/3 * ddx_.at(var_index - 1) * delta_s_sq_
    + 1/6 * ddx_.at(var_index) * delta_s_sq_;
    
    var_index ++;
  }
  // Cleanup
  osqp_cleanup(osqp_work);
  FreeData(data);
  c_free(settings);
  return true;
}

// OSQPSettings* PiecewiseJerkSpeedProblem::SolverDefaultSettings() {
//     // Define Solver default settings
//     OSQPSettings* settings =
//         reinterpret_cast<OSQPSettings*>(c_malloc(sizeof(OSQPSettings)));
//     osqp_set_default_settings(settings);
//     settings->eps_abs = 1e-4;
//     settings->eps_rel = 1e-4;
//     settings->eps_prim_inf = 1e-5;
//     settings->eps_dual_inf = 1e-5;
//     settings->polish = true;
//     settings->verbose = false;
//     settings->scaled_termination = true;

//     return settings;
// }
OSQPSettings* PiecewiseJerkSpeedProblem::SolverDefaultSettings() {
  // Define Solver default settings
  OSQPSettings* settings =
      reinterpret_cast<OSQPSettings*>(c_malloc(sizeof(OSQPSettings)));
  osqp_set_default_settings(settings);
  settings->eps_abs = 0.00025;
  settings->eps_rel = 0.00025;
  settings->eps_prim_inf = 0.000025;
  settings->eps_dual_inf = 0.000025;
  settings->polish = true;
  //settings->verbose = FLAGS_enable_osqp_debug;
  settings->verbose = false;
  settings->scaled_termination = true;

  return settings;
}
}
