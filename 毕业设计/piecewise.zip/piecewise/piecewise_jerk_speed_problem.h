#pragma once

#include <utility>
#include <vector>

#include "piecewise_jerk_problem.h"
#include <Eigen/Dense>

namespace navigation {

class PiecewiseJerkSpeedProblem : public PiecewiseJerkProblem {
 public:
  PiecewiseJerkSpeedProblem(const size_t num_of_knots, const double delta_s,
                            const std::array<double, 3>& x_init);

  virtual ~PiecewiseJerkSpeedProblem() = default;

  void set_dx_ref(const double weight_dx_ref, const double dx_ref);

  void set_penalty_dx(std::vector<double> penalty_dx);

  bool Optimize(const int max_iter) override;

  int n_of_knots;
  int segment_num;
  int traj_order;
  int n_poly;

  std::vector<double> x_skew_;
  std::vector<double> x_bias_;

  Eigen::MatrixXd M;

 protected:
  // naming convention follows osqp solver.
  void CalculateKernel(std::vector<c_float>* P_data,
                       std::vector<c_int>* P_indices,
                       std::vector<c_int>* P_indptr) override;

  void CalculateOffset(std::vector<c_float>* q) override;

  OSQPSettings* SolverDefaultSettings() override;

  OSQPData* FormulateProblem() override;

  void CalculateAffineConstraint(
    std::vector<c_float>* A_data, std::vector<c_int>* A_indices,
    std::vector<c_int>* A_indptr, std::vector<c_float>* lower_bounds,
    std::vector<c_float>* upper_bounds) override;

  bool has_dx_ref_ = false;
  double weight_dx_ref_ = 0.0;
  double dx_ref_ = 0.0;

  std::vector<double> penalty_dx_;
};

}
