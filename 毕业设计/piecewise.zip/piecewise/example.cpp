/*#include <fstream>
#include <iostream>
#include <iomanip>
#include "logging.h"
#include "piecewise_jerk_speed_problem.h"

std::vector<std::pair<double, double>> x_bounds;
std::vector<std::pair<double, double>> dx_bounds;
std::vector<double> x_ref;
std::vector<double> x_kappa;
std::vector<double> penalty_dx;
using namespace std;
using namespace navigation;
int main(int argc, char const* argv[]) {
  ifstream ifs("/home/qucd/Documents/piecewise/jerk_speed.txt");
  if (!ifs.is_open()) {
    cout << "Not Found" << endl;
  return 1;
  }

  int num_of_knots;
  double delta_t, acc_weight, jerk_weight;
  std::array<double, 3> init_s;
  ifs >> num_of_knots >> delta_t;
  ifs >> init_s[0] >> init_s[1] >> init_s[2];
  ifs >> acc_weight >> jerk_weight;

  AWARN << "knots:" << num_of_knots << " delta t:" << delta_t;
  AWARN << "s:" << init_s[0] << " v:" << init_s[1] << " a:" << init_s[2];
  AWARN << "w_acc: " << acc_weight << " w_jerk:" << jerk_weight;

  double val[5];
  for (int i = 0; i < num_of_knots; i++) {
    ifs >> val[0] >> val[1];
    x_bounds.emplace_back(val[0], val[1]);
  }
  for (int i = 0; i < num_of_knots; i++) {
    ifs >> val[0] >> val[1];
    dx_bounds.emplace_back(val[0], val[1]);
  }
  for (int i = 0; i < num_of_knots; i++) {
    ifs >> val[0];
    x_ref.emplace_back(val[0]);
    // x_bounds[i].first = max(0.0, val[0] - 1.0);
    // x_bounds[i].second = val[0] + 1.0;
  }
  for (int i = 0; i < num_of_knots; i++) {
    ifs >> val[0];
    x_kappa.emplace_back(val[0]);
  }

  dx_bounds[0].second = max(dx_bounds[0].second, init_s[1]);

  //num_of_knots = 70;

  PiecewiseJerkSpeedProblem piecewise_jerk_problem(num_of_knots, delta_t,
                                                   init_s);
  piecewise_jerk_problem.set_scale_factor({1.0, 1.0, 10.0});

  piecewise_jerk_problem.set_weight_ddx(acc_weight);
  piecewise_jerk_problem.set_weight_dddx(jerk_weight);
  piecewise_jerk_problem.set_ddx_bounds(-2.5, 1);
  piecewise_jerk_problem.set_dddx_bound(-40, 40);

  piecewise_jerk_problem.set_x_bounds(x_bounds);
  piecewise_jerk_problem.set_dx_bounds(dx_bounds);

  // piecewise_jerk_problem.set_penalty_dx(penalty_dx);
  piecewise_jerk_problem.set_x_ref(10.0, x_ref);
  piecewise_jerk_problem.set_dx_ref(0.0, 1.2);

  auto start_time = std::chrono::system_clock::now();
  bool success = piecewise_jerk_problem.Optimize(4000);
  auto end_time = std::chrono::system_clock::now();
  std::chrono::duration<double> diff = end_time - start_time;
  ADEBUG << "Speed Optimizer used time: " << diff.count() * 1000 << " ms.";
  if (!success) {
    std::string msg("Piecewise jerk speed optimizer failed!");
    AERROR << msg;
  }
  // Extract output
  const std::vector<double>& s = piecewise_jerk_problem.opt_x();
  const std::vector<double>& ds = piecewise_jerk_problem.opt_dx();
  const std::vector<double>& dds = piecewise_jerk_problem.opt_ddx();
  bool is_verbose = true;
  for (int i = 0; i < num_of_knots && is_verbose; ++i) {
    double ddds = (i == 0) ? (dds[1] - dds[0]) / delta_t
                           : (dds[i] - dds[i - 1]) / delta_t;
    cout << std::fixed << std::setprecision(3) << "For t[" << i * delta_t
         << "], opt = " << s[i] << ", " << ds[i] << ", " << dds[i] << ", "
         << ddds << endl;
  }
  // ADEBUG << "Speed Optimizer used time: " << diff.count() * 1000 << " ms.";
  return 0;
}*/



#include <fstream>
#include <iostream>
#include <iomanip>
#include <cmath>
#include "logging.h"
#include "piecewise_jerk_speed_problem.h"

std::vector<std::pair<double, double>> x_bounds;
std::vector<std::pair<double, double>> dx_bounds;
std::vector<double> x_ref;
std::vector<double> x_kappa;
std::vector<double> penalty_dx;
using namespace std;
using namespace navigation;
int main(int argc, char const* argv[]) {
  ifstream ifs("/home/qucd/Documents/piecewise/jerk_speed_my.txt");
  //ifstream ifs("piecewise/jerk_speed.txt");
  if (!ifs.is_open()) {
    cout << "Not Found" << endl;
  return 1;
  }
  double mscale = 10.0;
  int num_of_knots;
  double delta_t, acc_weight, jerk_weight;
  std::array<double, 3> init_s;
  ifs >> num_of_knots >> delta_t;
  ifs >> init_s[0] >> init_s[1] >> init_s[2];
  ifs >> acc_weight >> jerk_weight;

  init_s[1] = init_s[1] * mscale;

  AWARN << "knots:" << num_of_knots << " delta t:" << delta_t;
  AWARN << "s:" << init_s[0] << " v:" << init_s[1] << " a:" << init_s[2];
  AWARN << "w_acc: " << acc_weight << " w_jerk:" << jerk_weight;

  double val[5];
  for (int i = 0; i < num_of_knots; i++) {
    ifs >> val[0] >> val[1];
    x_bounds.emplace_back(mscale * val[0], mscale * val[1]);
  }
  for (int i = 0; i < num_of_knots; i++) {
    ifs >> val[0] >> val[1];
    dx_bounds.emplace_back(mscale * val[0], mscale * val[1]);
  }
  for (int i = 0; i < num_of_knots; i++) {
    ifs >> val[0];
    x_ref.emplace_back(mscale * val[0]);
    // x_bounds[i].first = max(0.0, val[0] - 1.0);
    // x_bounds[i].second = val[0] + 1.0;
  }
  for (int i = 0; i < num_of_knots; i++) {
    ifs >> val[0];
    x_kappa.emplace_back(val[0]);
  }

  dx_bounds[0].second = max(dx_bounds[0].second, init_s[1]);

  //num_of_knots = 70;

  PiecewiseJerkSpeedProblem piecewise_jerk_problem(num_of_knots, delta_t,
                                                   init_s);
  piecewise_jerk_problem.set_scale_factor({1.0, 1.0, 1.0});

  piecewise_jerk_problem.set_weight_ddx(acc_weight);
  piecewise_jerk_problem.set_weight_dddx(jerk_weight);
  piecewise_jerk_problem.set_ddx_bounds(-2.5, 1.5);
  piecewise_jerk_problem.set_dddx_bound(-40, 40);

  piecewise_jerk_problem.set_x_bounds(x_bounds);
  piecewise_jerk_problem.set_dx_bounds(dx_bounds);

  // piecewise_jerk_problem.set_penalty_dx(penalty_dx);
  piecewise_jerk_problem.set_x_ref(0.10, x_ref);
  piecewise_jerk_problem.set_dx_ref(0.10, 1.2 * mscale);

  auto start_time = std::chrono::system_clock::now();
  bool success = piecewise_jerk_problem.Optimize(4000);
  auto end_time = std::chrono::system_clock::now();
  std::chrono::duration<double> diff = end_time - start_time;
  ADEBUG << "Speed Optimizer used time: " << diff.count() * 1000 << " ms.";
  if (!success) {
    std::string msg("Piecewise jerk speed optimizer failed!");
    AERROR << msg;
  }
  // Extract output
  const std::vector<double>& s = piecewise_jerk_problem.opt_x();
  const std::vector<double>& ds = piecewise_jerk_problem.opt_dx();
  const std::vector<double>& dds = piecewise_jerk_problem.opt_ddx();
  bool is_verbose = true;
  double a_cost = 0.0;
  double mmax_a = 0.0;
  for (int i = 0; i < num_of_knots && is_verbose; ++i) {
    double ddds = (i == 0) ? (dds[1] - dds[0]) / delta_t
                           : (dds[i] - dds[i - 1]) / delta_t;

    a_cost += dds[i] * dds[i] * delta_t;
    mmax_a = max(mmax_a, abs(dds[i]));

    cout << std::fixed << std::setprecision(3) << "For t[" << i * delta_t
         << "], opt = " << s[i] << ", " << ds[i] << ", " << dds[i] << ", "
         << ddds << endl;
  }
  a_cost = acc_weight * sqrt(a_cost/(num_of_knots * delta_t));
  cout << "mmax_a " << mmax_a << endl;
  cout << "a_cost " << a_cost << endl;

  ofstream ofs("/home/qucd/Documents/piecewise/plot_st.txt");
  if (!ofs.is_open()) {
    cout << "Not Found" << endl;
  return 1;
  }

  for (int i = 0; i < num_of_knots && is_verbose; ++i) 
  {
    ofs << std::fixed << std::setprecision(3) << i * delta_t << " "
        << s[i] << " " << ds[i]  << " " << dds[i] << endl;
  }
  // ADEBUG << "Speed Optimizer used time: " << diff.count() * 1000 << " ms.";
  return 0;
}

